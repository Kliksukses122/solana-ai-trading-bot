'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import {
  Activity,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Bot,
  Wallet,
  BarChart3,
  Settings,
  RefreshCw,
  Pause,
  Play,
  Zap,
  Target,
  Shield,
  Clock,
  DollarSign,
  Percent,
  ArrowUpRight,
  ArrowDownRight,
  ExternalLink,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  formatNumber,
  formatCurrency,
  formatPercent,
  formatAddress,
  formatTime,
  formatDuration,
  getWinRateColor,
  getPnLColor,
  cn,
} from '@/lib/utils';

// Types
interface Trade {
  id: string;
  tokenMint: string;
  symbol?: string;
  action: 'BUY' | 'SELL';
  amount: number;
  price: number;
  pnl: number;
  timestamp: number;
  status: string;
  mock?: boolean;
}

interface Opportunity {
  tokenMint: string;
  symbol?: string;
  price: number;
  liquidity: number;
  volume24h: number;
  priceChange24h: number;
  score: number;
  type: string;
  timestamp: number;
}

interface Position {
  tokenMint: string;
  symbol?: string;
  action: string;
  amount: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  timestamp: number;
}

interface AgentStatus {
  name: string;
  isRunning?: boolean;
  monitoredTokens?: number;
  whaleWallets?: number;
  recentOpportunities?: number;
  cacheSize?: number;
  historySize?: number;
  minConfidence?: number;
  mlEnabled?: boolean;
  emergencyStop?: boolean;
  activePositions?: number;
  dailyPnL?: number;
  dailyTrades?: number;
  mockMode?: boolean;
  pendingTransactions?: number;
  completedTrades?: number;
  totalTrades?: number;
  performanceMetrics?: {
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    totalPnL: number;
    winRate: number;
    profitFactor: number;
    maxDrawdown: number;
  };
}

interface WalletInfo {
  address: string;
  balance: number;
  balanceUsd: number;
}

interface BotState {
  status: string;
  mockMode: boolean;
  startTime: number;
  wallet: WalletInfo;
  agents: {
    scout: AgentStatus;
    analyst: AgentStatus;
    risk: AgentStatus;
    trader: AgentStatus;
    memory: AgentStatus;
  };
  performance: {
    totalTrades: number;
    winRate: number;
    totalPnL: number;
    profitFactor: number;
    maxDrawdown: number;
    avgHoldingTime: number;
  };
  recentTrades: Trade[];
  opportunities: Opportunity[];
  positions: Position[];
}

// Default state - will be populated from WebSocket
const initialData: BotState = {
  status: 'stopped',
  mockMode: false,
  startTime: Date.now(),
  wallet: {
    address: 'vQuaowFLXdwN8Xt1z1YaZGtLTPWnpz1mYUvLsZjVVTJ',
    balance: 0,
    balanceUsd: 0,
  },
  agents: {
    scout: { name: 'ScoutAgent', isRunning: false, monitoredTokens: 0, whaleWallets: 0, recentOpportunities: 0 },
    analyst: { name: 'AnalystAgent', cacheSize: 0, historySize: 0, minConfidence: 0.65, mlEnabled: true },
    risk: { name: 'RiskAgent', emergencyStop: false, activePositions: 0, dailyPnL: 0, dailyTrades: 0 },
    trader: { name: 'TraderAgent', mockMode: false, pendingTransactions: 0, completedTrades: 0 },
    memory: { name: 'MemoryAgent', totalTrades: 0, performanceMetrics: { totalTrades: 0, winningTrades: 0, losingTrades: 0, totalPnL: 0, winRate: 0, profitFactor: 0, maxDrawdown: 0 } },
  },
  performance: { totalTrades: 0, winRate: 0, totalPnL: 0, profitFactor: 0, maxDrawdown: 0, avgHoldingTime: 0 },
  recentTrades: [],
  opportunities: [],
  positions: [],
};

// Generate mock chart data
const generateChartData = () => {
  const data = [];
  let value = 100;
  for (let i = 0; i < 24; i++) {
    value += (Math.random() - 0.45) * 5;
    data.push({
      time: `${i}h`,
      value: Math.max(80, value),
      pnl: value - 100,
    });
  }
  return data;
};

export default function Dashboard() {
  const [botState, setBotState] = useState<BotState>(initialData);
  const [socket, setSocket] = useState<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [chartData] = useState(generateChartData());
  const [selectedTab, setSelectedTab] = useState<'overview' | 'trades' | 'positions' | 'agents'>('overview');

  // WebSocket connection to trading bot API
  useEffect(() => {
    // Connect directly to the trading bot API on port 3030
    const newSocket = io('http://localhost:3030', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
    });

    newSocket.on('connect', () => {
      console.log('Connected to trading bot API');
      setConnected(true);
      // Request initial state
      newSocket.emit('get-status');
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from trading bot API');
      setConnected(false);
    });

    newSocket.on('connect_error', (error: Error) => {
      console.log('Connection error:', error.message);
      setConnected(false);
    });

    // Full state update
    newSocket.on('state', (state: BotState) => {
      console.log('Received state update:', state.status, 'wallet:', state.wallet?.balance);
      setBotState(state);
    });

    // Partial state update
    newSocket.on('state-update', (update: BotState) => {
      setBotState(prev => ({ ...prev, ...update }));
    });

    // Status response
    newSocket.on('status', (state: BotState) => {
      setBotState(state);
    });

    // Balance update
    newSocket.on('balance-update', (wallet: WalletInfo) => {
      setBotState(prev => ({ ...prev, wallet }));
    });

    newSocket.on('new-trade', (trade: Trade) => {
      setBotState(prev => ({
        ...prev,
        recentTrades: [trade, ...prev.recentTrades.slice(0, 99)],
      }));
    });

    newSocket.on('new-opportunity', (opportunity: Opportunity) => {
      setBotState(prev => ({
        ...prev,
        opportunities: [opportunity, ...prev.opportunities.slice(0, 9)],
      }));
    });

    newSocket.on('status-change', ({ status }: { status: string }) => {
      setBotState(prev => ({ ...prev, status }));
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, []);

  // Control handlers
  const handleStartBot = useCallback(() => {
    socket?.emit('start-bot');
  }, [socket]);

  const handleStopBot = useCallback(() => {
    socket?.emit('stop-bot');
  }, [socket]);

  const handleManualTrade = useCallback((tokenMint: string, action: 'BUY' | 'SELL') => {
    socket?.emit('manual-trade', { tokenMint, action, amount: 0.01 });
  }, [socket]);

  const isRunning = botState.status === 'running';
  const uptime = botState.startTime ? formatDuration(Date.now() - botState.startTime) : '0s';
  const walletBalance = botState.wallet?.balance || 0;
  const walletAddress = botState.wallet?.address || 'vQuaowFLXdwN8Xt1z1YaZGtLTPWnpz1mYUvLsZjVVTJ';

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Bot className="w-8 h-8 text-cyan-400" />
                <h1 className="text-2xl font-bold gradient-text">Solana AI Trading Bot</h1>
              </div>
              <Badge variant={isRunning ? 'success' : 'danger'} className="flex items-center gap-1">
                <span className={cn('w-2 h-2 rounded-full', isRunning ? 'bg-green-400 animate-pulse' : 'bg-red-400')} />
                {isRunning ? 'Running' : 'Stopped'}
              </Badge>
              {botState.mockMode ? (
                <Badge variant="warning">Mock Mode</Badge>
              ) : (
                <Badge variant="danger" className="animate-pulse">🔴 LIVE</Badge>
              )}
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>Uptime: {uptime}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className={cn('w-2 h-2 rounded-full', connected ? 'bg-green-400' : 'bg-red-400')} />
                <span className="text-sm text-muted-foreground">
                  {connected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              <div className="flex gap-2">
                {isRunning ? (
                  <Button variant="destructive" size="sm" onClick={handleStopBot}>
                    <Pause className="w-4 h-4 mr-2" />
                    Stop
                  </Button>
                ) : (
                  <Button variant="success" size="sm" onClick={handleStartBot}>
                    <Play className="w-4 h-4 mr-2" />
                    Start
                  </Button>
                )}
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex gap-2 mt-4">
            {(['overview', 'trades', 'positions', 'agents'] as const).map(tab => (
              <Button
                key={tab}
                variant={selectedTab === tab ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSelectedTab(tab)}
                className="capitalize"
              >
                {tab}
              </Button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {selectedTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatsCard
                title="Total P&L"
                value={formatCurrency(botState.performance.totalPnL)}
                subtitle="All time profit/loss"
                icon={<DollarSign className="w-5 h-5" />}
                trend={botState.performance.totalPnL >= 0 ? 'up' : 'down'}
                color={botState.performance.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}
              />
              <StatsCard
                title="Win Rate"
                value={`${botState.performance.winRate.toFixed(1)}%`}
                subtitle={`${botState.performance.totalTrades} trades`}
                icon={<Target className="w-5 h-5" />}
                color={getWinRateColor(botState.performance.winRate / 100)}
              />
              <StatsCard
                title="Profit Factor"
                value={botState.performance.profitFactor.toFixed(2)}
                subtitle="Gross profit / Gross loss"
                icon={<BarChart3 className="w-5 h-5" />}
                color={botState.performance.profitFactor >= 1 ? 'text-green-400' : 'text-red-400'}
              />
              <StatsCard
                title="Max Drawdown"
                value={`${botState.performance.maxDrawdown.toFixed(1)}%`}
                subtitle="Maximum peak decline"
                icon={<TrendingDown className="w-5 h-5" />}
                color="text-yellow-400"
              />
            </div>

            {/* Wallet & Deposit Section */}
            <Card className="bg-gradient-to-r from-cyan-900/20 to-purple-900/20 border-cyan-500/30">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-full bg-cyan-500/20">
                      <Wallet className="w-6 h-6 text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">Wallet</h3>
                      <p className="text-sm text-muted-foreground">Real balance from Solana</p>
                    </div>
                  </div>
                  <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Balance</p>
                      <p className="text-2xl font-bold text-white">
                        {walletBalance.toFixed(4)} SOL
                      </p>
                      <p className="text-xs text-muted-foreground">
                        ≈ ${(botState.wallet?.balanceUsd || 0).toFixed(2)} USD
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-cyan-400 border-cyan-500/50 hover:bg-cyan-500/10"
                        onClick={() => navigator.clipboard.writeText(walletAddress)}
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Copy Address
                      </Button>
                      <Button 
                        variant="default" 
                        size="sm"
                        className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                        onClick={() => {
                          navigator.clipboard.writeText(walletAddress);
                          // Open Solscan for the wallet
                          window.open(`https://solscan.io/account/${walletAddress}`, '_blank');
                        }}
                      >
                        💰 View on Solscan
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs text-muted-foreground">Wallet Address:</p>
                  <code className="text-sm text-cyan-400 font-mono break-all">
                    {walletAddress}
                  </code>
                </div>
              </CardContent>
            </Card>

            {/* Chart and Opportunities */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Performance Chart */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-cyan-400" />
                    Portfolio Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData}>
                        <defs>
                          <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="chart-grid" />
                        <XAxis dataKey="time" stroke="#6b7280" fontSize={12} />
                        <YAxis stroke="#6b7280" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#1e293b',
                            border: '1px solid #334155',
                            borderRadius: '8px',
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="value"
                          stroke="#22d3ee"
                          fillOpacity={1}
                          fill="url(#colorValue)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Opportunities */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    Opportunities
                  </CardTitle>
                  <CardDescription>Detected trading opportunities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-[280px] overflow-y-auto">
                    {botState.opportunities.length === 0 ? (
                      <p className="text-muted-foreground text-sm">No opportunities detected</p>
                    ) : (
                      botState.opportunities.map((opp, i) => (
                        <OpportunityCard key={i} opportunity={opp} onTrade={handleManualTrade} />
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Active Positions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-purple-400" />
                  Active Positions
                </CardTitle>
              </CardHeader>
              <CardContent>
                {botState.positions.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No active positions</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Token</th>
                          <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Type</th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Amount</th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Entry</th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Current</th>
                          <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">P&L</th>
                        </tr>
                      </thead>
                      <tbody>
                        {botState.positions.map((pos, i) => (
                          <tr key={i} className="border-b border-border/50 hover:bg-muted/50">
                            <td className="py-3 px-4">
                              <div className="font-medium">{pos.symbol || formatAddress(pos.tokenMint)}</div>
                            </td>
                            <td className="py-3 px-4">
                              <Badge variant={pos.action === 'BUY' ? 'success' : 'danger'}>
                                {pos.action}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-right">{formatNumber(pos.amount, 4)}</td>
                            <td className="py-3 px-4 text-right">{formatNumber(pos.entryPrice, 6)}</td>
                            <td className="py-3 px-4 text-right">{formatNumber(pos.currentPrice, 6)}</td>
                            <td className="py-3 px-4 text-right">
                              <div className={getPnLColor(pos.pnl)}>
                                <div>{formatCurrency(pos.pnl)}</div>
                                <div className="text-xs">{formatPercent(pos.pnlPercent)}</div>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {selectedTab === 'trades' && (
          <Card>
            <CardHeader>
              <CardTitle>Trade History</CardTitle>
              <CardDescription>Recent completed trades</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Time</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Token</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Type</th>
                      <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Amount</th>
                      <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">Price</th>
                      <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">P&L</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {botState.recentTrades.slice(0, 50).map((trade, i) => (
                      <tr key={trade.id || i} className="border-b border-border/50 hover:bg-muted/50">
                        <td className="py-3 px-4 text-sm text-muted-foreground">
                          {formatTime(trade.timestamp)}
                        </td>
                        <td className="py-3 px-4 font-medium">
                          {trade.symbol || formatAddress(trade.tokenMint)}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={trade.action === 'BUY' ? 'success' : 'danger'}>
                            {trade.action}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">{formatNumber(trade.amount, 4)}</td>
                        <td className="py-3 px-4 text-right">{formatNumber(trade.price, 6)}</td>
                        <td className={cn('py-3 px-4 text-right', getPnLColor(trade.pnl))}>
                          {trade.pnl !== 0 ? formatCurrency(trade.pnl) : '-'}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={trade.status === 'COMPLETED' ? 'success' : 'warning'}>
                            {trade.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {selectedTab === 'positions' && (
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Position Management</CardTitle>
              </CardHeader>
              <CardContent>
                {botState.positions.length === 0 ? (
                  <div className="text-center py-12">
                    <Wallet className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No active positions</p>
                    <p className="text-sm text-muted-foreground mt-2">Positions will appear here when trades are executed</p>
                  </div>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {botState.positions.map((pos, i) => (
                      <PositionCard key={i} position={pos} />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {selectedTab === 'agents' && (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <AgentCard
              name="Scout Agent"
              icon={<Activity className="w-5 h-5" />}
              status={botState.agents.scout}
              metrics={[
                { label: 'Monitored Tokens', value: botState.agents.scout.monitoredTokens || 0 },
                { label: 'Whale Wallets', value: botState.agents.scout.whaleWallets || 0 },
                { label: 'Recent Opportunities', value: botState.agents.scout.recentOpportunities || 0 },
              ]}
            />
            <AgentCard
              name="Analyst Agent"
              icon={<BarChart3 className="w-5 h-5" />}
              status={botState.agents.analyst}
              metrics={[
                { label: 'Cache Size', value: botState.agents.analyst.cacheSize || 0 },
                { label: 'History Size', value: botState.agents.analyst.historySize || 0 },
                { label: 'Min Confidence', value: `${((botState.agents.analyst.minConfidence || 0) * 100).toFixed(0)}%` },
                { label: 'ML Enabled', value: botState.agents.analyst.mlEnabled ? 'Yes' : 'No' },
              ]}
            />
            <AgentCard
              name="Risk Agent"
              icon={<Shield className="w-5 h-5" />}
              status={botState.agents.risk}
              metrics={[
                { label: 'Emergency Stop', value: botState.agents.risk.emergencyStop ? 'Active' : 'Inactive', warning: botState.agents.risk.emergencyStop },
                { label: 'Active Positions', value: botState.agents.risk.activePositions || 0 },
                { label: 'Daily P&L', value: formatCurrency(botState.agents.risk.dailyPnL || 0) },
                { label: 'Daily Trades', value: botState.agents.risk.dailyTrades || 0 },
              ]}
            />
            <AgentCard
              name="Trader Agent"
              icon={<Zap className="w-5 h-5" />}
              status={botState.agents.trader}
              metrics={[
                { label: 'Mode', value: botState.agents.trader.mockMode ? 'Mock' : 'Live' },
                { label: 'Pending TXs', value: botState.agents.trader.pendingTransactions || 0 },
                { label: 'Completed Trades', value: botState.agents.trader.completedTrades || 0 },
              ]}
            />
            <AgentCard
              name="Memory Agent"
              icon={<Clock className="w-5 h-5" />}
              status={botState.agents.memory}
              metrics={[
                { label: 'Total Trades', value: botState.agents.memory.totalTrades || 0 },
                { label: 'Win Rate', value: `${((botState.agents.memory.performanceMetrics?.winRate || 0) * 100).toFixed(1)}%` },
                { label: 'Total P&L', value: formatCurrency(botState.agents.memory.performanceMetrics?.totalPnL || 0) },
              ]}
            />
          </div>
        )}
      </main>
    </div>
  );
}

// Stats Card Component
function StatsCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  color,
}: {
  title: string;
  value: string;
  subtitle: string;
  icon: React.ReactNode;
  trend?: 'up' | 'down';
  color?: string;
}) {
  return (
    <Card className="card-hover">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className={cn('text-2xl font-bold mt-1', color)}>{value}</p>
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          </div>
          <div className={cn('p-3 rounded-full bg-muted', color)}>
            {trend === 'up' ? <TrendingUp className="w-5 h-5" /> : trend === 'down' ? <TrendingDown className="w-5 h-5" /> : icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Opportunity Card Component
function OpportunityCard({
  opportunity,
  onTrade,
}: {
  opportunity: Opportunity;
  onTrade: (mint: string, action: 'BUY' | 'SELL') => void;
}) {
  return (
    <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
      <div className="flex items-center justify-between mb-2">
        <div className="font-medium">{opportunity.symbol || formatAddress(opportunity.tokenMint)}</div>
        <Badge variant={opportunity.type === 'MOMENTUM' ? 'success' : opportunity.type === 'DIP' ? 'warning' : 'info'}>
          {opportunity.type}
        </Badge>
      </div>
      <div className="grid grid-cols-2 gap-2 text-sm">
        <div>
          <span className="text-muted-foreground">Score:</span>
          <span className="ml-1 font-medium">{(opportunity.score * 100).toFixed(0)}%</span>
        </div>
        <div>
          <span className="text-muted-foreground">24h:</span>
          <span className={cn('ml-1', opportunity.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400')}>
            {formatPercent(opportunity.priceChange24h)}
          </span>
        </div>
      </div>
      <div className="flex gap-2 mt-2">
        <Button size="sm" variant="success" className="flex-1" onClick={() => onTrade(opportunity.tokenMint, 'BUY')}>
          Buy
        </Button>
        <Button size="sm" variant="outline" className="flex-1">
          <ExternalLink className="w-3 h-3" />
        </Button>
      </div>
    </div>
  );
}

// Position Card Component
function PositionCard({ position }: { position: Position }) {
  return (
    <Card className="card-hover">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center text-white font-bold">
              {(position.symbol || 'T')[0]}
            </div>
            <div>
              <div className="font-medium">{position.symbol || formatAddress(position.tokenMint)}</div>
              <Badge variant={position.action === 'BUY' ? 'success' : 'danger'} className="text-xs">
                {position.action}
              </Badge>
            </div>
          </div>
          <div className={cn('text-right', getPnLColor(position.pnl))}>
            <div className="font-bold">{formatCurrency(position.pnl)}</div>
            <div className="text-xs">{formatPercent(position.pnlPercent)}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-muted-foreground">Amount</div>
            <div className="font-medium">{formatNumber(position.amount, 4)}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Entry</div>
            <div className="font-medium">{formatNumber(position.entryPrice, 6)}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Current</div>
            <div className="font-medium">{formatNumber(position.currentPrice, 6)}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Opened</div>
            <div className="font-medium">{formatTime(position.timestamp)}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Agent Card Component
function AgentCard({
  name,
  icon,
  status,
  metrics,
}: {
  name: string;
  icon: React.ReactNode;
  status: AgentStatus;
  metrics: { label: string; value: string | number; warning?: boolean }[];
}) {
  return (
    <Card className="card-hover">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <span className="text-cyan-400">{icon}</span>
            {name}
          </CardTitle>
          {status.isRunning !== undefined && (
            <Badge variant={status.isRunning ? 'success' : 'danger'} className="text-xs">
              {status.isRunning ? 'Running' : 'Stopped'}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {metrics.map((metric, i) => (
            <div key={i} className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{metric.label}</span>
              <span className={cn('font-medium', metric.warning && 'text-yellow-400')}>{metric.value}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

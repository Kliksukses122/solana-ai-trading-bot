/**
 * Solana AI Trading Bot - Main Entry Point
 * Multi-agent trading system with Jupiter integration
 */

import { config, validateConfig } from './config/config.js';
import { eventBus, EventTypes } from './core/eventBus.js';
import logger from './utils/logger.js';
import managerAgent from './agents/managerAgent.js';
import stateBridge from './services/stateBridge.js';
import walletService from './services/walletService.js';

// Banner
const BANNER = `
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ███████╗ █████╗ ███████╗ █████╗ ██╗  ██╗                   ║
║   ██╔════╝██╔══██╗██╔════╝██╔══██╗██║ ██╔╝                   ║
║   ███████╗███████║███████╗███████║█████╔╝                    ║
║   ╚════██║██╔══██║╚════██║██╔══██║██╔═██╗                    ║
║   ███████║██║  ██║███████║██║  ██║██║  ██╗                   ║
║   ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝                   ║
║                                                               ║
║   ██████╗ ██╗   ██╗████████╗████████╗ ██████╗ ███╗   ███╗    ║
║   ██╔══██╗██║   ██║╚══██╔══╝╚══██╔══╝██╔═══██╗████╗ ████║    ║
║   ██████╔╝██║   ██║   ██║      ██║   ██║   ██║██╬█████╔╝    ║
║   ██╔══██╗██║   ██║   ██║      ██║   ██║   ██║██╬╚██╔╝      ║
║   ██████╔╝╚██████╔╝   ██║      ██║   ╚██████╔╝██║ ╚═╝ ██║    ║
║   ╚═════╝  ╚═════╝    ╚═╝      ╚═╝    ╚═════╝ ╚═╝     ╚═╝    ║
║                                                               ║
║   Multi-Agent AI Trading Bot for Solana                      ║
║   Version 1.0.0                                               ║
╚═══════════════════════════════════════════════════════════════╝
`;

class TradingBot {
  constructor() {
    this.isRunning = false;
    this.startTime = null;
    this.shutdownInProgress = false;
    this.stateUpdateInterval = null;
    this.balanceUpdateInterval = null;
  }

  /**
   * Start the trading bot
   */
  async start() {
    console.log(BANNER);

    logger.info('Starting Solana AI Trading Bot...');
    logger.info(`Mode: ${config.bot.mockMode ? 'MOCK (Paper Trading)' : 'LIVE'}`);

    // Validate configuration
    const configValid = validateConfig();
    if (!configValid && !config.bot.mockMode) {
      logger.error('Configuration validation failed. Exiting.');
      process.exit(1);
    }

    try {
      // Initialize state bridge first
      await stateBridge.initialize();
      stateBridge.updateStatus('initializing');
      stateBridge.startPeriodicSave(1000);

      // Initialize wallet service
      await walletService.initialize();
      
      // Update state with wallet info
      const walletStatus = walletService.getStatus();
      if (walletStatus.address) {
        stateBridge.updateWallet(walletStatus.address, 0, 0);
      }

      this.startTime = Date.now();
      stateBridge.updateStatus('initializing');

      // Initialize manager agent (which initializes all other agents)
      await managerAgent.initialize();

      // Setup event listeners for state updates
      this.setupStateEventListeners();

      // Setup shutdown handlers
      this.setupShutdownHandlers();

      // Start the bot
      managerAgent.start();
      this.isRunning = true;
      stateBridge.updateStatus('running');

      logger.success('Trading bot started successfully!');
      logger.info('Press Ctrl+C to stop the bot');

      // Log initial status
      this.logStatus();

      // Setup status logging interval
      this.setupStatusLogging();

      // Setup state update interval
      this.setupStateUpdates();

      // Setup balance update interval
      this.setupBalanceUpdates();

    } catch (error) {
      logger.error('Failed to start trading bot', { error: error.message });
      stateBridge.updateStatus('error');
      stateBridge.saveState();
      process.exit(1);
    }
  }

  /**
   * Setup event listeners for state updates
   */
  setupStateEventListeners() {
    // Listen for all events and update state accordingly
    
    // Scout events
    eventBus.subscribe(EventTypes.SCOUT_OPPORTUNITY_FOUND, (event) => {
      stateBridge.addOpportunity(event.data);
      stateBridge.addEvent({
        type: 'opportunity',
        action: 'found',
        tokenMint: event.data.tokenMint,
        symbol: event.data.symbol,
        score: event.data.score,
      });
    });

    eventBus.subscribe(EventTypes.SCOUT_WHALE_ACTIVITY, (event) => {
      stateBridge.addEvent({
        type: 'whale_activity',
        data: event.data,
      });
    });

    // Analyst events
    eventBus.subscribe(EventTypes.ANALYST_SIGNAL_GENERATED, (event) => {
      stateBridge.addEvent({
        type: 'signal',
        tokenMint: event.data.tokenMint,
        action: event.data.signal?.direction || event.data.signal?.action,
        confidence: event.data.signal?.confidence,
        reason: event.data.reason,
      });
    });

    // Risk events
    eventBus.subscribe(EventTypes.RISK_APPROVED, (event) => {
      stateBridge.addEvent({
        type: 'risk',
        action: 'approved',
        tokenMint: event.data.tokenMint,
      });
    });

    eventBus.subscribe(EventTypes.RISK_REJECTED, (event) => {
      stateBridge.addEvent({
        type: 'risk',
        action: 'rejected',
        tokenMint: event.data.tokenMint,
        failures: event.data.failures?.map(f => f.check),
      });
    });

    eventBus.subscribe(EventTypes.RISK_EMERGENCY_STOP, (event) => {
      stateBridge.addEvent({
        type: 'emergency_stop',
        reason: event.data.reason,
      });
      stateBridge.updateAgent('risk', { emergencyStop: true });
    });

    // Trader events
    eventBus.subscribe(EventTypes.TRADER_SWAP_SUCCESS, (event) => {
      const trade = {
        id: event.data.tradeId || `trade_${Date.now()}`,
        tokenMint: event.data.tokenMint,
        symbol: event.data.symbol,
        action: event.data.action,
        amount: event.data.amount,
        price: event.data.price,
        pnl: event.data.pnl || 0,
        timestamp: event.data.timestamp || Date.now(),
        status: 'COMPLETED',
        signature: event.data.signature,
        mock: event.data.mock,
      };
      stateBridge.addTrade(trade);
      stateBridge.addEvent({
        type: 'trade',
        action: event.data.action,
        tokenMint: event.data.tokenMint,
        amount: event.data.amount,
        signature: event.data.signature,
        success: true,
      });
    });

    eventBus.subscribe(EventTypes.TRADER_SWAP_FAILED, (event) => {
      stateBridge.addEvent({
        type: 'trade',
        action: event.data.action,
        tokenMint: event.data.tokenMint,
        error: event.data.error,
        success: false,
      });
    });

    // Memory events
    eventBus.subscribe(EventTypes.MEMORY_STATS_UPDATED, (event) => {
      const metrics = event.data;
      stateBridge.updatePerformance({
        totalTrades: metrics.totalTrades,
        winRate: (metrics.winRate || 0) * 100,
        totalPnL: metrics.totalPnL || 0,
        profitFactor: metrics.profitFactor || 0,
        maxDrawdown: metrics.maxDrawdown || 0,
        avgHoldingTime: metrics.avgHoldingTime || 0,
      });
    });

    // System events
    eventBus.subscribe(EventTypes.SYSTEM_ERROR, (event) => {
      stateBridge.addEvent({
        type: 'error',
        error: event.data.error || event.data.reason,
      });
    });
  }

  /**
   * Stop the trading bot
   */
  async stop() {
    if (this.shutdownInProgress) return;
    this.shutdownInProgress = true;

    logger.info('Stopping trading bot...');
    stateBridge.updateStatus('stopping');

    try {
      // Stop intervals
      if (this.stateUpdateInterval) {
        clearInterval(this.stateUpdateInterval);
      }
      if (this.balanceUpdateInterval) {
        clearInterval(this.balanceUpdateInterval);
      }

      managerAgent.stop();
      this.isRunning = false;

      // Final state update
      await this.updateFullState();

      // Log final status
      const status = managerAgent.getStatus();
      const memoryStatus = status.agents.memory;

      logger.info('Bot stopped', {
        uptime: this.getUptime(),
        tradesProcessed: status.stats.tradesProcessed,
        totalTrades: memoryStatus.totalTrades,
      });

      stateBridge.updateStatus('stopped');
      stateBridge.stopPeriodicSave();

    } catch (error) {
      logger.error('Error during shutdown', { error: error.message });
      stateBridge.updateStatus('error');
      stateBridge.saveState();
    }
  }

  /**
   * Setup shutdown handlers
   */
  setupShutdownHandlers() {
    // Handle Ctrl+C
    process.on('SIGINT', async () => {
      logger.info('Received SIGINT signal');
      await this.stop();
      process.exit(0);
    });

    // Handle kill command
    process.on('SIGTERM', async () => {
      logger.info('Received SIGTERM signal');
      await this.stop();
      process.exit(0);
    });

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      logger.error('Uncaught exception', { error: error.message, stack: error.stack });
      eventBus.emitEvent(EventTypes.SYSTEM_ERROR, {
        type: 'uncaughtException',
        error: error.message,
      });
    });

    // Handle unhandled promise rejections
    process.on('unhandledRejection', (reason, promise) => {
      logger.error('Unhandled promise rejection', { reason: String(reason) });
      eventBus.emitEvent(EventTypes.SYSTEM_ERROR, {
        type: 'unhandledRejection',
        reason: String(reason),
      });
    });
  }

  /**
   * Setup periodic status logging
   */
  setupStatusLogging() {
    setInterval(() => {
      if (this.isRunning) {
        this.logStatus();
      }
    }, 60000); // Every minute
  }

  /**
   * Setup state updates interval
   */
  setupStateUpdates() {
    this.stateUpdateInterval = setInterval(() => {
      if (this.isRunning) {
        this.updateFullState();
      }
    }, 2000); // Every 2 seconds
  }

  /**
   * Setup balance updates interval
   */
  setupBalanceUpdates() {
    // Update balance every 30 seconds
    this.balanceUpdateInterval = setInterval(async () => {
      if (this.isRunning) {
        try {
          const balance = await walletService.getBalanceSol();
          const walletStatus = walletService.getStatus();
          stateBridge.updateWallet(walletStatus.address, balance, balance * 150); // Rough USD estimate
        } catch (error) {
          logger.debug('Failed to update balance', { error: error.message });
        }
      }
    }, 30000);
  }

  /**
   * Update full state from manager agent
   */
  async updateFullState() {
    try {
      const status = managerAgent.getStatus();
      const memoryStatus = status.agents.memory;
      const memoryMetrics = memoryStatus.performanceMetrics || {};

      // Update all agent states
      stateBridge.updateAllAgents({
        scout: status.agents.scout,
        analyst: status.agents.analyst,
        risk: status.agents.risk,
        trader: status.agents.trader,
        memory: {
          name: 'MemoryAgent',
          totalTrades: memoryStatus.totalTrades,
          performanceMetrics: memoryMetrics,
        },
      });

      // Update performance
      stateBridge.updatePerformance({
        totalTrades: memoryMetrics.totalTrades || 0,
        winRate: (memoryMetrics.winRate || 0) * 100,
        totalPnL: memoryMetrics.totalPnL || 0,
        profitFactor: memoryMetrics.profitFactor || 0,
        maxDrawdown: memoryMetrics.maxDrawdown || 0,
        avgHoldingTime: memoryMetrics.avgHoldingTime || 0,
      });

      // Update positions from risk agent
      const positions = status.agents.risk?.activePositions || [];
      if (Array.isArray(positions)) {
        stateBridge.updatePositions(positions);
      }

    } catch (error) {
      logger.debug('Failed to update full state', { error: error.message });
    }
  }

  /**
   * Log current status
   */
  logStatus() {
    const status = managerAgent.getStatus();
    const memory = status.agents.memory;

    logger.info('Bot Status', {
      uptime: this.getUptime(),
      running: status.isRunning,
      queueSize: status.queueSize,
      cooldowns: status.activeCooldowns,
      stats: {
        loopsCompleted: status.stats.loopsCompleted,
        tradesProcessed: status.stats.tradesProcessed,
        tradesApproved: status.stats.tradesApproved,
        tradesRejected: status.stats.tradesRejected,
      },
      performance: {
        totalTrades: memory.totalTrades,
        winRate: memory.performanceMetrics?.winRate
          ? `${(memory.performanceMetrics.winRate * 100).toFixed(1)}%`
          : 'N/A',
        totalPnL: memory.performanceMetrics?.totalPnL?.toFixed(4) || '0',
      },
    });
  }

  /**
   * Get uptime string
   */
  getUptime() {
    if (!this.startTime) return '0s';

    const uptimeMs = Date.now() - this.startTime;
    const hours = Math.floor(uptimeMs / 3600000);
    const minutes = Math.floor((uptimeMs % 3600000) / 60000);
    const seconds = Math.floor((uptimeMs % 60000) / 1000);

    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  }
}

// Create and start bot
const bot = new TradingBot();

// Start the bot
bot.start().catch((error) => {
  logger.error('Fatal error', { error: error.message });
  process.exit(1);
});

export default bot;

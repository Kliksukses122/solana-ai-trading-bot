/**
 * Risk Agent - Risk Management and Trade Validation
 * Enforces position sizing, stop loss, take profit, and risk limits
 */

import { eventBus, EventTypes } from '../core/eventBus.js';
import { config } from '../config/config.js';
import walletService from '../services/walletService.js';
import logger from '../utils/logger.js';

class RiskAgent {
  constructor() {
    this.name = 'RiskAgent';
    this.activePositions = new Map();
    this.dailyPnL = 0;
    this.dailyTrades = 0;
    this.lastResetDate = new Date().toDateString();
    this.tradeHistory = [];
    this.maxHistorySize = 1000;

    // Risk configuration
    this.maxRiskPercent = config.trading.maxRiskPercent;
    this.stopLossPercent = config.trading.stopLossPercent;
    this.takeProfitPercent = config.trading.takeProfitPercent;
    this.maxPositionSizePercent = config.risk.maxPositionSizePercent;
    this.maxDailyLossPercent = config.risk.maxDailyLossPercent;
    this.maxDrawdownPercent = config.risk.maxDrawdownPercent;
    this.maxOpenTrades = config.trading.maxOpenTrades;

    // Emergency stop
    this.emergencyStop = false;
    this.emergencyStopReason = null;

    // Blacklisted tokens
    this.blacklist = new Set(config.risk.blacklistTokens);
    this.whitelist = new Set(config.risk.whitelistTokens);
  }

  /**
   * Initialize the risk agent
   */
  async initialize() {
    logger.agent(this.name, 'Initializing...');
    this.setupEventListeners();
    logger.agent(this.name, 'Initialized successfully');
    return this;
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Listen for trade approvals from Manager
    eventBus.subscribe(EventTypes.MANAGER_TRADE_APPROVED, async (event) => {
      await this.evaluateRisk(event.data);
    });

    // Listen for successful trades to track positions
    eventBus.subscribe(EventTypes.TRADER_SWAP_SUCCESS, (event) => {
      this.recordPosition(event.data);
    });

    // Listen for trade failures
    eventBus.subscribe(EventTypes.TRADER_SWAP_FAILED, (event) => {
      this.handleTradeFailure(event.data);
    });

    // Listen for system stop
    eventBus.subscribe(EventTypes.SYSTEM_STOP, () => {
      this.emergencyStopAll('System shutdown');
    });
  }

  /**
   * Evaluate risk for a potential trade
   */
  async evaluateRisk(tradeRequest) {
    const startTime = Date.now();

    try {
      // Reset daily stats if new day
      this.checkDailyReset();

      const {
        tokenMint,
        action,
        amount,
        signal,
        price,
      } = tradeRequest;

      logger.agent(this.name, 'Evaluating risk', { tokenMint, action, amount });

      // Run all risk checks
      const checks = {
        emergencyStop: this.checkEmergencyStop(),
        blacklist: this.checkBlacklist(tokenMint),
        dailyLoss: this.checkDailyLossLimit(),
        positionLimit: this.checkPositionLimit(),
        positionSize: await this.checkPositionSize(amount),
        balance: await this.checkBalance(amount),
        confidence: this.checkSignalConfidence(signal),
        drawdown: this.checkDrawdown(),
        duplicatePosition: this.checkDuplicatePosition(tokenMint, action),
      };

      // Collect any failures
      const failures = [];
      for (const [checkName, result] of Object.entries(checks)) {
        if (!result.passed) {
          failures.push({
            check: checkName,
            reason: result.reason,
            severity: result.severity || 'HIGH',
          });
        }
      }

      // Calculate position sizing
      const positionSizing = await this.calculatePositionSize(tradeRequest, checks);

      // Calculate stop loss and take profit
      const exitLevels = this.calculateExitLevels(price, action);

      // Determine if trade is approved
      const approved = failures.length === 0 && !this.emergencyStop;

      const evaluation = {
        approved,
        tokenMint,
        action,
        originalAmount: amount,
        approvedAmount: approved ? positionSizing.recommendedAmount : 0,
        riskPercent: positionSizing.riskPercent,
        stopLoss: exitLevels.stopLoss,
        takeProfit: exitLevels.takeProfit,
        riskRewardRatio: exitLevels.riskRewardRatio,
        checks,
        failures,
        timestamp: Date.now(),
      };

      // Emit result
      if (approved) {
        eventBus.emitEvent(EventTypes.RISK_APPROVED, evaluation);
        logger.agent(this.name, 'Trade APPROVED', {
          tokenMint,
          action,
          amount: positionSizing.recommendedAmount,
          riskPercent: positionSizing.riskPercent,
        });
      } else {
        eventBus.emitEvent(EventTypes.RISK_REJECTED, evaluation);
        logger.agent(this.name, 'Trade REJECTED', {
          tokenMint,
          action,
          failures: failures.map(f => f.check),
        });
      }

      const duration = Date.now() - startTime;
      logger.performance('risk_evaluation', duration);

      return evaluation;
    } catch (error) {
      logger.error('Risk evaluation failed', { error: error.message });

      eventBus.emitEvent(EventTypes.RISK_REJECTED, {
        approved: false,
        error: error.message,
        timestamp: Date.now(),
      });

      return {
        approved: false,
        error: error.message,
      };
    }
  }

  /**
   * Check emergency stop status
   */
  checkEmergencyStop() {
    if (this.emergencyStop) {
      return {
        passed: false,
        reason: `Emergency stop active: ${this.emergencyStopReason}`,
        severity: 'CRITICAL',
      };
    }
    return { passed: true };
  }

  /**
   * Check if token is blacklisted
   */
  checkBlacklist(tokenMint) {
    // Check blacklist
    if (this.blacklist.has(tokenMint)) {
      return {
        passed: false,
        reason: 'Token is blacklisted',
        severity: 'HIGH',
      };
    }

    // Check whitelist if configured
    if (this.whitelist.size > 0 && !this.whitelist.has(tokenMint)) {
      return {
        passed: false,
        reason: 'Token not in whitelist',
        severity: 'MEDIUM',
      };
    }

    return { passed: true };
  }

  /**
   * Check daily loss limit
   */
  checkDailyLossLimit() {
    const balance = walletService.getBalanceSol ? 100 : 100; // Mock balance
    const dailyLossLimit = balance * (this.maxDailyLossPercent / 100);
    const currentLoss = Math.abs(Math.min(0, this.dailyPnL));

    if (currentLoss >= dailyLossLimit) {
      return {
        passed: false,
        reason: `Daily loss limit reached: ${currentLoss.toFixed(4)} / ${dailyLossLimit.toFixed(4)}`,
        severity: 'HIGH',
      };
    }

    return {
      passed: true,
      currentLoss,
      limit: dailyLossLimit,
    };
  }

  /**
   * Check open position limit
   */
  checkPositionLimit() {
    const openCount = this.activePositions.size;

    if (openCount >= this.maxOpenTrades) {
      return {
        passed: false,
        reason: `Maximum open positions reached: ${openCount} / ${this.maxOpenTrades}`,
        severity: 'MEDIUM',
      };
    }

    return {
      passed: true,
      openPositions: openCount,
      maxPositions: this.maxOpenTrades,
    };
  }

  /**
   * Check position size
   */
  async checkPositionSize(amount) {
    const balance = await walletService.getBalanceSol();
    const maxPositionSize = balance * (this.maxPositionSizePercent / 100);

    if (amount > maxPositionSize) {
      return {
        passed: false,
        reason: `Position size exceeds max: ${amount.toFixed(4)} > ${maxPositionSize.toFixed(4)} SOL`,
        severity: 'MEDIUM',
      };
    }

    return {
      passed: true,
      amount,
      maxAllowed: maxPositionSize,
    };
  }

  /**
   * Check wallet balance
   */
  async checkBalance(amount) {
    try {
      const balance = await walletService.getBalanceSol();

      if (balance < amount) {
        return {
          passed: false,
          reason: `Insufficient balance: ${balance.toFixed(4)} < ${amount.toFixed(4)} SOL`,
          severity: 'HIGH',
        };
      }

      return {
        passed: true,
        balance,
        requested: amount,
      };
    } catch (error) {
      return {
        passed: false,
        reason: `Balance check failed: ${error.message}`,
        severity: 'HIGH',
      };
    }
  }

  /**
   * Check signal confidence
   */
  checkSignalConfidence(signal) {
    if (!signal) {
      return {
        passed: true,
        reason: 'No signal provided',
      };
    }

    const minConfidence = config.scoring.minConfidenceScore;

    if (signal.confidence < minConfidence * 0.5) {
      return {
        passed: false,
        reason: `Signal confidence too low: ${signal.confidence.toFixed(2)}`,
        severity: 'LOW',
      };
    }

    return {
      passed: true,
      confidence: signal.confidence,
      action: signal.action,
    };
  }

  /**
   * Check overall drawdown
   */
  checkDrawdown() {
    // Calculate drawdown from trade history
    let peak = 0;
    let current = 0;
    let maxDrawdown = 0;

    for (const trade of this.tradeHistory) {
      current += trade.pnl || 0;
      if (current > peak) {
        peak = current;
      }
      const drawdown = peak > 0 ? (peak - current) / peak : 0;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
    }

    if (maxDrawdown * 100 > this.maxDrawdownPercent) {
      return {
        passed: false,
        reason: `Max drawdown exceeded: ${(maxDrawdown * 100).toFixed(2)}%`,
        severity: 'HIGH',
      };
    }

    return {
      passed: true,
      currentDrawdown: maxDrawdown * 100,
      maxAllowed: this.maxDrawdownPercent,
    };
  }

  /**
   * Check for duplicate positions
   */
  checkDuplicatePosition(tokenMint, action) {
    const existingPosition = this.activePositions.get(tokenMint);

    if (existingPosition) {
      // Allow if action is opposite (closing position)
      if (existingPosition.action !== action) {
        return { passed: true, closingPosition: true };
      }

      return {
        passed: false,
        reason: `Duplicate position exists for ${tokenMint}`,
        severity: 'MEDIUM',
      };
    }

    return { passed: true };
  }

  /**
   * Calculate optimal position size
   */
  async calculatePositionSize(tradeRequest, checks) {
    const { amount } = tradeRequest;

    // Get balance
    const balance = await walletService.getBalanceSol();

    // Calculate maximum risk amount
    const maxRiskAmount = balance * (this.maxRiskPercent / 100);

    // Calculate based on stop loss
    const stopLossAmount = maxRiskAmount / (this.stopLossPercent / 100);

    // Take the minimum of all constraints
    const constraints = [
      amount,
      balance * (this.maxPositionSizePercent / 100),
      stopLossAmount,
    ];

    if (checks.positionSize?.maxAllowed) {
      constraints.push(checks.positionSize.maxAllowed);
    }

    const recommendedAmount = Math.min(...constraints);
    const riskPercent = (recommendedAmount / balance) * 100;

    return {
      recommendedAmount,
      maxRiskAmount,
      riskPercent,
      constraints: {
        requested: amount,
        maxPositionSize: balance * (this.maxPositionSizePercent / 100),
        stopLossBased: stopLossAmount,
      },
    };
  }

  /**
   * Calculate exit levels (stop loss and take profit)
   */
  calculateExitLevels(price, action) {
    const stopLossMultiplier = this.stopLossPercent / 100;
    const takeProfitMultiplier = this.takeProfitPercent / 100;

    let stopLoss, takeProfit;

    if (action === 'BUY') {
      stopLoss = price * (1 - stopLossMultiplier);
      takeProfit = price * (1 + takeProfitMultiplier);
    } else {
      stopLoss = price * (1 + stopLossMultiplier);
      takeProfit = price * (1 - takeProfitMultiplier);
    }

    const risk = Math.abs(price - stopLoss);
    const reward = Math.abs(takeProfit - price);
    const riskRewardRatio = reward / risk;

    return {
      stopLoss,
      takeProfit,
      stopLossPercent: this.stopLossPercent,
      takeProfitPercent: this.takeProfitPercent,
      riskRewardRatio,
    };
  }

  /**
   * Record a new position
   */
  recordPosition(tradeData) {
    const {
      tokenMint,
      action,
      amount,
      price,
      signature,
    } = tradeData;

    const position = {
      tokenMint,
      action,
      amount,
      price,
      signature,
      entryTime: Date.now(),
      stopLoss: price * (action === 'BUY' ? (1 - this.stopLossPercent / 100) : (1 + this.stopLossPercent / 100)),
      takeProfit: price * (action === 'BUY' ? (1 + this.takeProfitPercent / 100) : (1 - this.takeProfitPercent / 100)),
      status: 'OPEN',
    };

    this.activePositions.set(tokenMint, position);
    this.dailyTrades++;

    logger.agent(this.name, 'Position recorded', {
      tokenMint,
      action,
      amount,
      stopLoss: position.stopLoss,
      takeProfit: position.takeProfit,
    });

    // Add to history
    this.tradeHistory.push({
      ...position,
      type: 'OPEN',
      timestamp: Date.now(),
    });

    this.trimHistory();
  }

  /**
   * Handle trade failure
   */
  handleTradeFailure(tradeData) {
    logger.agent(this.name, 'Trade failed', tradeData);
    // Could implement retry logic or alerting here
  }

  /**
   * Close a position
   */
  closePosition(tokenMint, exitPrice, pnl) {
    const position = this.activePositions.get(tokenMint);
    if (!position) return;

    position.exitPrice = exitPrice;
    position.pnl = pnl;
    position.exitTime = Date.now();
    position.status = 'CLOSED';

    this.activePositions.delete(tokenMint);
    this.dailyPnL += pnl;

    this.tradeHistory.push({
      ...position,
      type: 'CLOSE',
      timestamp: Date.now(),
    });

    this.trimHistory();

    // Check for emergency stop condition
    if (pnl < 0 && config.risk.emergencyStopEnabled) {
      const balance = walletService.getBalanceSol ? 100 : 100;
      if (Math.abs(this.dailyPnL) > balance * (this.maxDailyLossPercent / 100)) {
        this.triggerEmergencyStop('Daily loss limit exceeded');
      }
    }

    logger.agent(this.name, 'Position closed', {
      tokenMint,
      pnl,
      dailyPnL: this.dailyPnL,
    });

    return position;
  }

  /**
   * Check and reset daily stats
   */
  checkDailyReset() {
    const today = new Date().toDateString();
    if (today !== this.lastResetDate) {
      this.dailyPnL = 0;
      this.dailyTrades = 0;
      this.lastResetDate = today;
      logger.agent(this.name, 'Daily stats reset');
    }
  }

  /**
   * Trigger emergency stop
   */
  triggerEmergencyStop(reason) {
    this.emergencyStop = true;
    this.emergencyStopReason = reason;

    eventBus.emitEvent(EventTypes.RISK_EMERGENCY_STOP, {
      reason,
      timestamp: Date.now(),
      dailyPnL: this.dailyPnL,
      activePositions: this.activePositions.size,
    });

    logger.warn('EMERGENCY STOP triggered', { reason });
  }

  /**
   * Emergency stop all positions
   */
  async emergencyStopAll(reason) {
    this.triggerEmergencyStop(reason);

    // In production, this would trigger immediate sell orders
    logger.agent(this.name, 'Emergency stop all positions', {
      reason,
      activePositions: this.activePositions.size,
    });
  }

  /**
   * Reset emergency stop
   */
  resetEmergencyStop() {
    this.emergencyStop = false;
    this.emergencyStopReason = null;
    logger.agent(this.name, 'Emergency stop reset');
  }

  /**
   * Add token to blacklist
   */
  addToBlacklist(tokenMint) {
    this.blacklist.add(tokenMint);
    logger.agent(this.name, 'Token blacklisted', { tokenMint });
  }

  /**
   * Remove token from blacklist
   */
  removeFromBlacklist(tokenMint) {
    this.blacklist.delete(tokenMint);
    logger.agent(this.name, 'Token removed from blacklist', { tokenMint });
  }

  /**
   * Add token to whitelist
   */
  addToWhitelist(tokenMint) {
    this.whitelist.add(tokenMint);
    logger.agent(this.name, 'Token whitelisted', { tokenMint });
  }

  /**
   * Trim trade history
   */
  trimHistory() {
    if (this.tradeHistory.length > this.maxHistorySize) {
      this.tradeHistory = this.tradeHistory.slice(-this.maxHistorySize);
    }
  }

  /**
   * Get agent status
   */
  getStatus() {
    return {
      name: this.name,
      emergencyStop: this.emergencyStop,
      emergencyStopReason: this.emergencyStopReason,
      activePositions: this.activePositions.size,
      dailyPnL: this.dailyPnL,
      dailyTrades: this.dailyTrades,
      tradeHistorySize: this.tradeHistory.length,
      blacklistSize: this.blacklist.size,
      whitelistSize: this.whitelist.size,
      config: {
        maxRiskPercent: this.maxRiskPercent,
        stopLossPercent: this.stopLossPercent,
        takeProfitPercent: this.takeProfitPercent,
        maxDailyLossPercent: this.maxDailyLossPercent,
        maxDrawdownPercent: this.maxDrawdownPercent,
        maxOpenTrades: this.maxOpenTrades,
      },
    };
  }

  /**
   * Get active positions
   */
  getActivePositions() {
    return Array.from(this.activePositions.values());
  }

  /**
   * Get trade history
   */
  getTradeHistory(limit = 100) {
    return this.tradeHistory.slice(-limit);
  }
}

// Singleton instance
const riskAgent = new RiskAgent();

export { RiskAgent, riskAgent };
export default riskAgent;

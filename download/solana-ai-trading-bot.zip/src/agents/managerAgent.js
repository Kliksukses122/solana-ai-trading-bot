/**
 * Manager Agent - Orchestration and Coordination
 * Manages agent communication, cooldowns, and trade flow
 */

import { eventBus, EventTypes } from '../core/eventBus.js';
import { config } from '../config/config.js';
import logger from '../utils/logger.js';

// Import agents
import scoutAgent from './scoutAgent.js';
import analystAgent from './analystAgent.js';
import riskAgent from './riskAgent.js';
import traderAgent from './traderAgent.js';
import memoryAgent from './memoryAgent.js';

class ManagerAgent {
  constructor() {
    this.name = 'ManagerAgent';
    this.isRunning = false;
    this.loopInterval = null;

    // Cooldown management
    this.tokenCooldowns = new Map();
    this.cooldownMs = config.trading.cooldownSeconds * 1000;

    // Duplicate trade prevention
    this.recentTradeRequests = new Map();
    this.duplicateWindowMs = 10000; // 10 seconds

    // Trade queue
    this.tradeQueue = [];
    this.maxQueueSize = 10;

    // Agent references
    this.agents = {
      scout: scoutAgent,
      analyst: analystAgent,
      risk: riskAgent,
      trader: traderAgent,
      memory: memoryAgent,
    };

    // Statistics
    this.stats = {
      loopsCompleted: 0,
      tradesProcessed: 0,
      tradesApproved: 0,
      tradesRejected: 0,
      cooldownHits: 0,
      duplicatesBlocked: 0,
    };
  }

  /**
   * Initialize all agents and start the system
   */
  async initialize() {
    logger.agent(this.name, 'Initializing...');

    try {
      // Initialize all agents in order
      await this.agents.memory.initialize();
      await this.agents.scout.initialize();
      await this.agents.analyst.initialize();
      await this.agents.risk.initialize();
      await this.agents.trader.initialize();

      // Setup event listeners
      this.setupEventListeners();

      logger.agent(this.name, 'All agents initialized successfully');
      return this;
    } catch (error) {
      logger.error('Failed to initialize agents', { error: error.message });
      throw error;
    }
  }

  /**
   * Setup event listeners for agent coordination
   */
  setupEventListeners() {
    // Listen for analysis complete from Analyst
    eventBus.subscribe(EventTypes.ANALYST_ANALYSIS_COMPLETE, async (event) => {
      await this.handleAnalysis(event.data);
    });

    // Listen for signals from Analyst
    eventBus.subscribe(EventTypes.ANALYST_SIGNAL_GENERATED, async (event) => {
      await this.handleSignal(event.data);
    });

    // Listen for risk decisions
    eventBus.subscribe(EventTypes.RISK_APPROVED, (event) => {
      this.handleRiskApproval(event.data);
    });

    eventBus.subscribe(EventTypes.RISK_REJECTED, (event) => {
      this.handleRiskRejection(event.data);
    });

    // Listen for trade completion
    eventBus.subscribe(EventTypes.TRADER_SWAP_SUCCESS, (event) => {
      this.handleTradeSuccess(event.data);
    });

    eventBus.subscribe(EventTypes.TRADER_SWAP_FAILED, (event) => {
      this.handleTradeFailure(event.data);
    });

    // Listen for emergency stop
    eventBus.subscribe(EventTypes.RISK_EMERGENCY_STOP, (event) => {
      this.handleEmergencyStop(event.data);
    });
  }

  /**
   * Start the main bot loop
   */
  start() {
    if (this.isRunning) return;

    this.isRunning = true;
    logger.agent(this.name, 'Starting bot loop');

    // Emit system start event
    eventBus.emitEvent(EventTypes.SYSTEM_START, {
      timestamp: Date.now(),
      mockMode: config.bot.mockMode,
    });

    // Start scout agent
    this.agents.scout.start();

    // Main loop (orchestration tasks)
    this.loopInterval = setInterval(() => {
      this.mainLoop();
    }, 5000); // Every 5 seconds
  }

  /**
   * Stop the bot
   */
  stop() {
    if (!this.isRunning) return;

    this.isRunning = false;
    logger.agent(this.name, 'Stopping bot');

    // Stop scout agent
    this.agents.scout.stop();

    // Clear loop interval
    if (this.loopInterval) {
      clearInterval(this.loopInterval);
      this.loopInterval = null;
    }

    // Emit system stop event
    eventBus.emitEvent(EventTypes.SYSTEM_STOP, {
      timestamp: Date.now(),
    });
  }

  /**
   * Main orchestration loop
   */
  async mainLoop() {
    try {
      eventBus.emitEvent(EventTypes.MANAGER_LOOP_START, {
        loopId: this.stats.loopsCompleted,
      });

      // Process trade queue
      await this.processTradeQueue();

      // Update cooldowns
      this.updateCooldowns();

      // Clean up old data
      this.cleanupOldData();

      this.stats.loopsCompleted++;

      eventBus.emitEvent(EventTypes.MANAGER_LOOP_END, {
        loopId: this.stats.loopsCompleted - 1,
      });
    } catch (error) {
      logger.error('Main loop error', { error: error.message });
    }
  }

  /**
   * Handle analysis from Analyst Agent
   */
  async handleAnalysis(analysisData) {
    const { tokenMint, signal, analysis } = analysisData;

    // Check if we should act on this signal
    if (signal.action === 'HOLD') {
      logger.debug('Holding position', { tokenMint, confidence: signal.confidence });
      return;
    }

    // Check cooldown
    if (this.isCooldownActive(tokenMint)) {
      logger.debug('Token on cooldown', { tokenMint });
      this.stats.cooldownHits++;
      return;
    }

    // Check for duplicate request
    const requestId = this.generateRequestId(tokenMint, signal.action);
    if (this.isDuplicateRequest(requestId)) {
      logger.debug('Duplicate request blocked', { tokenMint, action: signal.action });
      this.stats.duplicatesBlocked++;
      eventBus.emitEvent(EventTypes.MANAGER_DUPLICATE_TRADE, {
        tokenMint,
        action: signal.action,
      });
      return;
    }

    // Create trade request
    const tradeRequest = {
      tokenMint,
      action: signal.action,
      amount: config.trading.tradeSizeSol,
      signal,
      analysis,
      requestId,
      timestamp: Date.now(),
    };

    // Add to queue
    this.queueTrade(tradeRequest);
  }

  /**
   * Handle signal from Analyst Agent
   */
  async handleSignal(signalData) {
    const { tokenMint, signal, reason } = signalData;

    logger.info('Signal received', {
      tokenMint,
      action: signal.direction || signal.action,
      confidence: signal.confidence,
      reason,
    });

    // Process high-confidence signals immediately
    if (signal.confidence >= config.scoring.minConfidenceScore) {
      const requestId = this.generateRequestId(tokenMint, signal.direction || signal.action);

      const tradeRequest = {
        tokenMint,
        action: signal.direction || signal.action,
        amount: config.trading.tradeSizeSol,
        signal,
        requestId,
        timestamp: Date.now(),
      };

      this.queueTrade(tradeRequest);
    }
  }

  /**
   * Queue a trade for processing
   */
  queueTrade(tradeRequest) {
    if (this.tradeQueue.length >= this.maxQueueSize) {
      logger.warn('Trade queue full, dropping oldest');
      this.tradeQueue.shift();
    }

    this.tradeQueue.push(tradeRequest);
    logger.agent(this.name, 'Trade queued', {
      tokenMint: tradeRequest.tokenMint,
      action: tradeRequest.action,
      queueSize: this.tradeQueue.length,
    });
  }

  /**
   * Process trade queue
   */
  async processTradeQueue() {
    while (this.tradeQueue.length > 0) {
      const tradeRequest = this.tradeQueue.shift();

      // Double-check cooldown
      if (this.isCooldownActive(tradeRequest.tokenMint)) {
        logger.debug('Skipping queued trade - cooldown active', {
          tokenMint: tradeRequest.tokenMint,
        });
        continue;
      }

      // Process through risk agent
      await this.agents.risk.evaluateRisk(tradeRequest);

      this.stats.tradesProcessed++;

      // Add small delay between trades
      await this.delay(100);
    }
  }

  /**
   * Handle risk approval
   */
  handleRiskApproval(tradeData) {
    logger.agent(this.name, 'Trade approved by Risk Agent', {
      tokenMint: tradeData.tokenMint,
      action: tradeData.action,
    });

    this.stats.tradesApproved++;

    eventBus.emitEvent(EventTypes.MANAGER_TRADE_APPROVED, tradeData);

    // Set cooldown after approval
    this.setCooldown(tradeData.tokenMint);
  }

  /**
   * Handle risk rejection
   */
  handleRiskRejection(tradeData) {
    logger.agent(this.name, 'Trade rejected by Risk Agent', {
      tokenMint: tradeData.tokenMint,
      failures: tradeData.failures?.map(f => f.check),
    });

    this.stats.tradesRejected++;

    eventBus.emitEvent(EventTypes.MANAGER_TRADE_REJECTED, tradeData);
  }

  /**
   * Handle successful trade
   */
  handleTradeSuccess(tradeData) {
    logger.agent(this.name, 'Trade completed successfully', {
      tokenMint: tradeData.tokenMint,
      signature: tradeData.signature,
    });

    // Set cooldown after successful trade
    this.setCooldown(tradeData.tokenMint);

    // Record in recent requests to prevent duplicates
    const requestId = this.generateRequestId(tradeData.tokenMint, tradeData.action);
    this.recentTradeRequests.set(requestId, Date.now());
  }

  /**
   * Handle failed trade
   */
  handleTradeFailure(tradeData) {
    logger.agent(this.name, 'Trade failed', {
      tokenMint: tradeData.tokenMint,
      error: tradeData.error,
    });

    // Could implement retry logic here
  }

  /**
   * Handle emergency stop
   */
  handleEmergencyStop(data) {
    logger.agent(this.name, 'EMERGENCY STOP triggered', data);

    // Stop all trading
    this.stop();

    // Could add notification logic here
  }

  /**
   * Check if token is on cooldown
   */
  isCooldownActive(tokenMint) {
    const cooldownEnd = this.tokenCooldowns.get(tokenMint);
    return cooldownEnd && Date.now() < cooldownEnd;
  }

  /**
   * Set cooldown for a token
   */
  setCooldown(tokenMint) {
    const cooldownEnd = Date.now() + this.cooldownMs;
    this.tokenCooldowns.set(tokenMint, cooldownEnd);

    eventBus.emitEvent(EventTypes.MANAGER_COOLDOWN_ACTIVE, {
      tokenMint,
      cooldownEnd,
      durationMs: this.cooldownMs,
    });

    logger.debug('Cooldown set', {
      tokenMint,
      duration: `${this.cooldownMs / 1000}s`,
    });
  }

  /**
   * Update cooldowns (remove expired)
   */
  updateCooldowns() {
    const now = Date.now();
    for (const [tokenMint, cooldownEnd] of this.tokenCooldowns) {
      if (now >= cooldownEnd) {
        this.tokenCooldowns.delete(tokenMint);
      }
    }
  }

  /**
   * Check for duplicate request
   */
  isDuplicateRequest(requestId) {
    const lastRequestTime = this.recentTradeRequests.get(requestId);
    if (!lastRequestTime) return false;

    return Date.now() - lastRequestTime < this.duplicateWindowMs;
  }

  /**
   * Generate unique request ID
   */
  generateRequestId(tokenMint, action) {
    return `${tokenMint}_${action}`;
  }

  /**
   * Clean up old data
   */
  cleanupOldData() {
    const now = Date.now();

    // Clean up old trade requests
    for (const [requestId, timestamp] of this.recentTradeRequests) {
      if (now - timestamp > this.duplicateWindowMs * 2) {
        this.recentTradeRequests.delete(requestId);
      }
    }
  }

  /**
   * Helper delay
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Get system status
   */
  getStatus() {
    return {
      name: this.name,
      isRunning: this.isRunning,
      stats: this.stats,
      queueSize: this.tradeQueue.length,
      activeCooldowns: this.tokenCooldowns.size,
      agents: {
        scout: this.agents.scout.getStatus(),
        analyst: this.agents.analyst.getStatus(),
        risk: this.agents.risk.getStatus(),
        trader: this.agents.trader.getStatus(),
        memory: this.agents.memory.getStatus(),
      },
    };
  }

  /**
   * Get performance report
   */
  getReport() {
    return {
      manager: this.getStatus(),
      performance: this.agents.memory.getPerformanceMetrics(),
      report: this.agents.memory.generateReport(),
      recentTrades: this.agents.memory.getTradeHistory(20),
    };
  }

  /**
   * Manual trade trigger (for testing)
   */
  async manualTrade(tokenMint, action, amount = null) {
    logger.agent(this.name, 'Manual trade requested', { tokenMint, action });

    const tradeRequest = {
      tokenMint,
      action,
      amount: amount || config.trading.tradeSizeSol,
      signal: {
        action,
        confidence: 1,
        reasons: ['Manual trade'],
      },
      requestId: this.generateRequestId(tokenMint, action),
      timestamp: Date.now(),
      manual: true,
    };

    return this.agents.risk.evaluateRisk(tradeRequest);
  }

  /**
   * Add token to monitor
   */
  async addToken(tokenMint) {
    await this.agents.scout.addTokenToMonitor(tokenMint);
  }

  /**
   * Add whale wallet
   */
  addWhaleWallet(address) {
    this.agents.scout.addWhaleWallet(address);
  }

  /**
   * Reset emergency stop
   */
  resetEmergencyStop() {
    this.agents.risk.resetEmergencyStop();
  }
}

// Singleton instance
const managerAgent = new ManagerAgent();

export { ManagerAgent, managerAgent };
export default managerAgent;

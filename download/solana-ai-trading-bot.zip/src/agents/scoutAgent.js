/**
 * Scout Agent - Token Discovery and Market Monitoring
 * Detects opportunities, tracks whales, and monitors market activity
 */

import { eventBus, EventTypes } from '../core/eventBus.js';
import { config } from '../config/config.js';
import dataService from '../services/dataService.js';
import logger from '../utils/logger.js';

class ScoutAgent {
  constructor() {
    this.name = 'ScoutAgent';
    this.isRunning = false;
    this.scanInterval = null;
    this.monitoredTokens = new Map();
    this.whaleWallets = new Set();
    this.recentOpportunities = [];
    this.maxOpportunities = 100;

    // Tracking data
    this.volumeHistory = new Map();
    this.priceHistory = new Map();
    this.whaleActivity = [];

    // Configuration
    this.scanIntervalMs = config.trading.scanIntervalMs;
    this.minLiquidity = config.trading.minLiquidityUsd;
    this.minVolume = config.trading.minVolume24h;
    this.whaleMinAmount = config.whaleTracking.minWhaleAmount;

    // Initialize tracked wallets
    if (config.whaleTracking.trackedWallets.length > 0) {
      config.whaleTracking.trackedWallets.forEach(addr => this.whaleWallets.add(addr));
    }
  }

  /**
   * Initialize the scout agent
   */
  async initialize() {
    logger.agent(this.name, 'Initializing...');
    this.setupEventListeners();
    logger.agent(this.name, 'Initialized successfully');
    return this;
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Listen for system events
    eventBus.subscribe(EventTypes.SYSTEM_START, () => this.start());
    eventBus.subscribe(EventTypes.SYSTEM_STOP, () => this.stop());

    // Listen for new token additions
    eventBus.subscribe('scout:add_token', async (event) => {
      await this.addTokenToMonitor(event.data.tokenMint);
    });
  }

  /**
   * Start scanning
   */
  start() {
    if (this.isRunning) return;

    this.isRunning = true;
    logger.agent(this.name, 'Starting scan loop');

    // Initial scan
    this.performScan();

    // Setup interval
    this.scanInterval = setInterval(() => {
      this.performScan();
    }, this.scanIntervalMs);
  }

  /**
   * Stop scanning
   */
  stop() {
    if (!this.isRunning) return;

    this.isRunning = false;
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
    }
    logger.agent(this.name, 'Stopped');
  }

  /**
   * Perform a scan cycle
   */
  async performScan() {
    const startTime = Date.now();

    try {
      // Parallel scan tasks
      const [priceUpdates, opportunities, whaleActivity] = await Promise.all([
        this.scanPriceUpdates(),
        this.scanOpportunities(),
        this.scanWhaleActivity(),
      ]);

      const duration = Date.now() - startTime;
      logger.debug(`Scan completed in ${duration}ms`, {
        priceUpdates: priceUpdates.length,
        opportunities: opportunities.length,
        whaleActivity: whaleActivity.length,
      });

    } catch (error) {
      logger.error('Scan failed', { error: error.message });
    }
  }

  /**
   * Scan for price updates on monitored tokens
   */
  async scanPriceUpdates() {
    const updates = [];
    const tokens = Array.from(this.monitoredTokens.keys());

    if (tokens.length === 0) {
      // Add default tokens to monitor
      this.addDefaultTokens();
      return updates;
    }

    try {
      // Fetch prices in batch
      const prices = await dataService.getMultipleTokenPrices(tokens);

      for (const [mint, priceData] of Object.entries(prices)) {
        const previousData = this.monitoredTokens.get(mint);
        const previousPrice = previousData?.price || 0;
        const currentPrice = priceData.price;

        // Store price history
        this.addToPriceHistory(mint, currentPrice);

        // Check for significant price change
        if (previousPrice > 0) {
          const priceChange = ((currentPrice - previousPrice) / previousPrice) * 100;

          if (Math.abs(priceChange) >= 2) { // 2% threshold
            const event = eventBus.emitEvent(EventTypes.SCOUT_PRICE_UPDATE, {
              tokenMint: mint,
              price: currentPrice,
              previousPrice,
              priceChange,
              timestamp: Date.now(),
            });
            updates.push(event);
          }
        }

        // Update monitored data
        this.monitoredTokens.set(mint, {
          ...previousData,
          price: currentPrice,
          lastUpdate: Date.now(),
        });
      }
    } catch (error) {
      logger.error('Failed to scan price updates', { error: error.message });
    }

    return updates;
  }

  /**
   * Scan for trading opportunities
   */
  async scanOpportunities() {
    const opportunities = [];

    try {
      // Scan monitored tokens for opportunities
      for (const [mint, data] of this.monitoredTokens) {
        const opportunity = await this.analyzeTokenForOpportunity(mint, data);
        if (opportunity) {
          opportunities.push(opportunity);
          this.addOpportunity(opportunity);

          // Emit opportunity event
          eventBus.emitEvent(EventTypes.SCOUT_OPPORTUNITY_FOUND, opportunity);
        }
      }

      // Scan for new/trending tokens periodically
      if (Math.random() < 0.1) { // 10% chance each scan
        await this.scanNewTokens();
      }

    } catch (error) {
      logger.error('Failed to scan opportunities', { error: error.message });
    }

    return opportunities;
  }

  /**
   * Analyze a token for trading opportunity
   */
  async analyzeTokenForOpportunity(mint, existingData) {
    try {
      const tokenInfo = await dataService.getTokenInfo(mint);
      if (!tokenInfo) return null;

      // Check liquidity requirement
      if (tokenInfo.liquidity < this.minLiquidity) {
        return null;
      }

      // Check volume requirement
      if (tokenInfo.volume24h < this.minVolume) {
        return null;
      }

      // Detect volume spike
      const volumeSpike = this.detectVolumeSpike(mint, tokenInfo.volume24h);
      if (volumeSpike) {
        eventBus.emitEvent(EventTypes.SCOUT_VOLUME_SPIKE, {
          tokenMint: mint,
          volume24h: tokenInfo.volume24h,
          spikeRatio: volumeSpike.ratio,
        });
      }

      // Calculate opportunity score
      const score = this.calculateOpportunityScore(tokenInfo, existingData);

      if (score >= 0.5) { // Minimum opportunity threshold
        return {
          tokenMint: mint,
          symbol: tokenInfo.symbol,
          price: tokenInfo.price,
          liquidity: tokenInfo.liquidity,
          volume24h: tokenInfo.volume24h,
          priceChange24h: tokenInfo.priceChange24h,
          score,
          timestamp: Date.now(),
          type: this.classifyOpportunity(tokenInfo),
        };
      }

      return null;
    } catch (error) {
      logger.error('Failed to analyze token', { mint, error: error.message });
      return null;
    }
  }

  /**
   * Calculate opportunity score
   */
  calculateOpportunityScore(tokenInfo, existingData) {
    let score = 0;

    // Price momentum (positive change = higher score)
    const priceChange = tokenInfo.priceChange24h || 0;
    score += Math.min(0.3, Math.abs(priceChange) / 100) * Math.sign(priceChange) + 0.15;

    // Volume score (higher volume = better liquidity)
    if (tokenInfo.volume24h > 100000) {
      score += 0.2;
    } else if (tokenInfo.volume24h > 50000) {
      score += 0.15;
    } else if (tokenInfo.volume24h > 10000) {
      score += 0.1;
    }

    // Liquidity score
    if (tokenInfo.liquidity > 100000) {
      score += 0.2;
    } else if (tokenInfo.liquidity > 50000) {
      score += 0.15;
    } else if (tokenInfo.liquidity > 10000) {
      score += 0.1;
    }

    // Trend alignment
    if (tokenInfo.priceChange1h > 0 && tokenInfo.priceChange6h > 0) {
      score += 0.15;
    }

    return Math.max(0, Math.min(1, score));
  }

  /**
   * Classify opportunity type
   */
  classifyOpportunity(tokenInfo) {
    if (tokenInfo.priceChange24h > 20) return 'MOMENTUM';
    if (tokenInfo.volume24h > tokenInfo.liquidity * 2) return 'HIGH_VOLUME';
    if (tokenInfo.priceChange24h < -20) return 'DIP';
    return 'STANDARD';
  }

  /**
   * Detect volume spike
   */
  detectVolumeSpike(mint, currentVolume) {
    const history = this.volumeHistory.get(mint) || [];
    if (history.length < 5) {
      this.addToVolumeHistory(mint, currentVolume);
      return null;
    }

    const avgVolume = history.reduce((a, b) => a + b, 0) / history.length;
    const ratio = currentVolume / avgVolume;

    this.addToVolumeHistory(mint, currentVolume);

    if (ratio > 2) { // 2x average volume
      return { ratio, avgVolume, currentVolume };
    }

    return null;
  }

  /**
   * Scan for whale activity
   */
  async scanWhaleActivity() {
    const activities = [];

    if (!config.whaleTracking.enabled) {
      return activities;
    }

    try {
      // In a real implementation, this would connect to:
      // - Helius webhooks for large transfers
      // - Birdeye whale tracking API
      // - On-chain transaction monitoring

      // Simulated whale detection for demonstration
      for (const wallet of this.whaleWallets) {
        // Check for recent large transactions
        // This is a placeholder - real implementation would use Helius/Birdeye APIs
        const activity = await this.checkWalletActivity(wallet);
        if (activity) {
          activities.push(activity);
          this.whaleActivity.push(activity);

          eventBus.emitEvent(EventTypes.SCOUT_WHALE_ACTIVITY, activity);
        }
      }

    } catch (error) {
      logger.error('Failed to scan whale activity', { error: error.message });
    }

    return activities;
  }

  /**
   * Check wallet activity (placeholder for real implementation)
   */
  async checkWalletActivity(walletAddress) {
    // Placeholder - in production, use Helius API or similar
    return null;
  }

  /**
   * Scan for new tokens
   */
  async scanNewTokens() {
    try {
      const newTokens = await dataService.scanNewTokens();

      for (const token of newTokens.slice(0, 5)) {
        // Emit new token event
        eventBus.emitEvent(EventTypes.SCOUT_NEW_TOKEN, {
          tokenMint: token.address,
          symbol: token.symbol,
          name: token.name,
          createdAt: token.createdAt,
        });

        // Add to monitoring if meets criteria
        if (token.address) {
          await this.addTokenToMonitor(token.address);
        }
      }
    } catch (error) {
      logger.error('Failed to scan new tokens', { error: error.message });
    }
  }

  /**
   * Add token to monitor
   */
  async addTokenToMonitor(mint) {
    if (this.monitoredTokens.has(mint)) return;

    try {
      const tokenInfo = await dataService.getTokenInfo(mint);
      if (tokenInfo) {
        this.monitoredTokens.set(mint, {
          ...tokenInfo,
          addedAt: Date.now(),
          lastUpdate: Date.now(),
        });
        logger.info('Token added to monitor', { mint, symbol: tokenInfo.symbol });
      }
    } catch (error) {
      logger.error('Failed to add token to monitor', { mint, error: error.message });
    }
  }

  /**
   * Add default tokens to monitor
   */
  addDefaultTokens() {
    const defaultTokens = config.tokenLists.popular;
    defaultTokens.forEach(mint => {
      if (!this.monitoredTokens.has(mint)) {
        this.monitoredTokens.set(mint, {
          price: 0,
          addedAt: Date.now(),
          lastUpdate: Date.now(),
        });
      }
    });
  }

  /**
   * Add whale wallet to track
   */
  addWhaleWallet(address) {
    this.whaleWallets.add(address);
    logger.info('Whale wallet added', { address });
  }

  /**
   * Helper: Add to price history
   */
  addToPriceHistory(mint, price) {
    if (!this.priceHistory.has(mint)) {
      this.priceHistory.set(mint, []);
    }
    const history = this.priceHistory.get(mint);
    history.push({ price, timestamp: Date.now() });
    if (history.length > 100) {
      history.shift();
    }
  }

  /**
   * Helper: Add to volume history
   */
  addToVolumeHistory(mint, volume) {
    if (!this.volumeHistory.has(mint)) {
      this.volumeHistory.set(mint, []);
    }
    const history = this.volumeHistory.get(mint);
    history.push(volume);
    if (history.length > 24) {
      history.shift();
    }
  }

  /**
   * Helper: Add opportunity
   */
  addOpportunity(opportunity) {
    this.recentOpportunities.push(opportunity);
    if (this.recentOpportunities.length > this.maxOpportunities) {
      this.recentOpportunities.shift();
    }
  }

  /**
   * Get agent status
   */
  getStatus() {
    return {
      name: this.name,
      isRunning: this.isRunning,
      monitoredTokens: this.monitoredTokens.size,
      whaleWallets: this.whaleWallets.size,
      recentOpportunities: this.recentOpportunities.length,
      scanIntervalMs: this.scanIntervalMs,
    };
  }

  /**
   * Get recent opportunities
   */
  getRecentOpportunities(limit = 10) {
    return this.recentOpportunities.slice(-limit);
  }

  /**
   * Get price history for token
   */
  getTokenPriceHistory(mint, limit = 50) {
    const history = this.priceHistory.get(mint) || [];
    return history.slice(-limit);
  }
}

// Singleton instance
const scoutAgent = new ScoutAgent();

export { ScoutAgent, scoutAgent };
export default scoutAgent;

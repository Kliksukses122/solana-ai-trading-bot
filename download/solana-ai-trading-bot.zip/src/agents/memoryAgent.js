/**
 * Memory Agent - Trade History and Performance Tracking
 * Stores trade history, calculates metrics, and provides analytics
 */

import { eventBus, EventTypes } from '../core/eventBus.js';
import { config } from '../config/config.js';
import logger from '../utils/logger.js';
import fs from 'fs';
import path from 'path';

class MemoryAgent {
  constructor() {
    this.name = 'MemoryAgent';
    this.tradeHistory = [];
    this.performanceMetrics = {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      totalPnL: 0,
      totalFees: 0,
      winRate: 0,
      avgWin: 0,
      avgLoss: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      maxDrawdown: 0,
      avgHoldingTime: 0,
      bestTrade: null,
      worstTrade: null,
    };
    this.maxHistorySize = config.memory.maxTradeHistory;
    this.stateFile = path.join(process.cwd(), 'data', 'state.json');
    this.persistInterval = config.memory.statePersistInterval;
    this.persistTimer = null;

    // Token performance tracking
    this.tokenPerformance = new Map();

    // Agent performance tracking
    this.agentStats = new Map();
  }

  /**
   * Initialize the memory agent
   */
  async initialize() {
    logger.agent(this.name, 'Initializing...');
    this.setupEventListeners();
    await this.loadState();
    this.startPersistTimer();
    logger.agent(this.name, 'Initialized successfully', {
      tradesLoaded: this.tradeHistory.length,
    });
    return this;
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Listen for completed trades
    eventBus.subscribe(EventTypes.TRADER_SWAP_SUCCESS, (event) => {
      this.recordTrade(event.data);
    });

    // Listen for failed trades
    eventBus.subscribe(EventTypes.TRADER_SWAP_FAILED, (event) => {
      this.recordFailedTrade(event.data);
    });

    // Listen for risk approved trades
    eventBus.subscribe(EventTypes.RISK_APPROVED, (event) => {
      this.recordRiskApproval(event.data);
    });

    // Listen for risk rejected trades
    eventBus.subscribe(EventTypes.RISK_REJECTED, (event) => {
      this.recordRiskRejection(event.data);
    });

    // Listen for system stop
    eventBus.subscribe(EventTypes.SYSTEM_STOP, () => {
      this.persistState();
      this.stopPersistTimer();
    });
  }

  /**
   * Record a completed trade
   */
  recordTrade(tradeData) {
    const trade = {
      id: tradeData.tradeId || this.generateTradeId(),
      tokenMint: tradeData.tokenMint,
      action: tradeData.action,
      amount: tradeData.amount,
      inAmount: tradeData.inAmount,
      outAmount: tradeData.outAmount,
      price: tradeData.price,
      signature: tradeData.signature,
      stopLoss: tradeData.stopLoss,
      takeProfit: tradeData.takeProfit,
      signal: tradeData.signal,
      timestamp: tradeData.timestamp || Date.now(),
      status: 'COMPLETED',
      mock: tradeData.mock,
      pnl: 0,
      fees: this.estimateFees(tradeData),
    };

    this.tradeHistory.push(trade);
    this.trimHistory();

    // Update metrics
    this.updatePerformanceMetrics();

    // Update token performance
    this.updateTokenPerformance(trade);

    // Update agent stats
    this.updateAgentStats('trader', 'success');

    // Emit recorded event
    eventBus.emitEvent(EventTypes.MEMORY_TRADE_RECORDED, trade);

    logger.agent(this.name, 'Trade recorded', {
      tradeId: trade.id,
      action: trade.action,
      tokenMint: trade.tokenMint,
    });

    return trade;
  }

  /**
   * Record a failed trade
   */
  recordFailedTrade(tradeData) {
    const failedTrade = {
      id: tradeData.tradeId || this.generateTradeId(),
      tokenMint: tradeData.tokenMint,
      action: tradeData.action,
      amount: tradeData.amount,
      error: tradeData.error,
      timestamp: tradeData.timestamp || Date.now(),
      status: 'FAILED',
    };

    this.tradeHistory.push(failedTrade);
    this.trimHistory();

    // Update agent stats
    this.updateAgentStats('trader', 'failure');

    logger.agent(this.name, 'Failed trade recorded', {
      tradeId: failedTrade.id,
      error: tradeData.error,
    });

    return failedTrade;
  }

  /**
   * Record risk approval
   */
  recordRiskApproval(data) {
    this.updateAgentStats('risk', 'approval');
  }

  /**
   * Record risk rejection
   */
  recordRiskRejection(data) {
    this.updateAgentStats('risk', 'rejection');
  }

  /**
   * Update PnL for a closed position
   */
  updatePnL(tradeId, exitPrice, pnl) {
    const trade = this.tradeHistory.find(t => t.id === tradeId);
    if (trade) {
      trade.exitPrice = exitPrice;
      trade.pnl = pnl;
      trade.closedAt = Date.now();
      trade.holdingTime = trade.closedAt - trade.timestamp;

      this.updatePerformanceMetrics();

      logger.agent(this.name, 'PnL updated', {
        tradeId,
        pnl,
        exitPrice,
      });
    }
  }

  /**
   * Update performance metrics
   */
  updatePerformanceMetrics() {
    const trades = this.tradeHistory.filter(t => t.status === 'COMPLETED');

    if (trades.length === 0) return;

    // Basic counts
    this.performanceMetrics.totalTrades = trades.length;

    // PnL calculations
    const pnlTrades = trades.filter(t => t.pnl !== undefined);
    this.performanceMetrics.winningTrades = pnlTrades.filter(t => t.pnl > 0).length;
    this.performanceMetrics.losingTrades = pnlTrades.filter(t => t.pnl < 0).length;
    this.performanceMetrics.totalPnL = pnlTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    this.performanceMetrics.totalFees = trades.reduce((sum, t) => sum + (t.fees || 0), 0);

    // Win rate
    this.performanceMetrics.winRate = pnlTrades.length > 0
      ? this.performanceMetrics.winningTrades / pnlTrades.length
      : 0;

    // Average win/loss
    const wins = pnlTrades.filter(t => t.pnl > 0).map(t => t.pnl);
    const losses = pnlTrades.filter(t => t.pnl < 0).map(t => t.pnl);

    this.performanceMetrics.avgWin = wins.length > 0
      ? wins.reduce((a, b) => a + b, 0) / wins.length
      : 0;

    this.performanceMetrics.avgLoss = losses.length > 0
      ? losses.reduce((a, b) => a + b, 0) / losses.length
      : 0;

    // Profit factor
    const totalWins = wins.reduce((a, b) => a + b, 0);
    const totalLosses = Math.abs(losses.reduce((a, b) => a + b, 0));
    this.performanceMetrics.profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;

    // Max drawdown
    this.performanceMetrics.maxDrawdown = this.calculateMaxDrawdown(pnlTrades);

    // Best/worst trades
    if (pnlTrades.length > 0) {
      this.performanceMetrics.bestTrade = pnlTrades.reduce((best, t) =>
        t.pnl > (best?.pnl || -Infinity) ? t : best, null);
      this.performanceMetrics.worstTrade = pnlTrades.reduce((worst, t) =>
        t.pnl < (worst?.pnl || Infinity) ? t : worst, null);
    }

    // Average holding time
    const closedTrades = trades.filter(t => t.holdingTime);
    this.performanceMetrics.avgHoldingTime = closedTrades.length > 0
      ? closedTrades.reduce((sum, t) => sum + t.holdingTime, 0) / closedTrades.length
      : 0;

    // Emit stats updated
    eventBus.emitEvent(EventTypes.MEMORY_STATS_UPDATED, this.performanceMetrics);
  }

  /**
   * Calculate maximum drawdown
   */
  calculateMaxDrawdown(trades) {
    if (trades.length === 0) return 0;

    let peak = 0;
    let current = 0;
    let maxDrawdown = 0;

    for (const trade of trades) {
      current += trade.pnl || 0;
      if (current > peak) {
        peak = current;
      }
      const drawdown = peak > 0 ? (peak - current) / peak : 0;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
    }

    return maxDrawdown * 100; // Return as percentage
  }

  /**
   * Update token performance
   */
  updateTokenPerformance(trade) {
    const mint = trade.tokenMint;
    if (!this.tokenPerformance.has(mint)) {
      this.tokenPerformance.set(mint, {
        tokenMint: mint,
        totalTrades: 0,
        winningTrades: 0,
        totalPnL: 0,
        totalVolume: 0,
        avgPnL: 0,
        winRate: 0,
      });
    }

    const perf = this.tokenPerformance.get(mint);
    perf.totalTrades++;
    perf.totalVolume += trade.amount || 0;

    if (trade.pnl !== undefined) {
      if (trade.pnl > 0) perf.winningTrades++;
      perf.totalPnL += trade.pnl;
      perf.avgPnL = perf.totalPnL / perf.totalTrades;
      perf.winRate = perf.winningTrades / perf.totalTrades;
    }

    this.tokenPerformance.set(mint, perf);
  }

  /**
   * Update agent statistics
   */
  updateAgentStats(agentName, statType) {
    const key = `${agentName}_${statType}`;
    this.agentStats.set(key, (this.agentStats.get(key) || 0) + 1);
  }

  /**
   * Estimate fees for a trade
   */
  estimateFees(trade) {
    // Approximate Solana transaction fees
    const baseFee = 0.000005; // 5000 lamports
    const jupiterFee = 0; // Jupiter doesn't charge fees

    // Estimate based on trade size
    const estimatedFee = baseFee + (trade.amount || 0) * 0.0001;

    return estimatedFee;
  }

  /**
   * Get trade history
   */
  getTradeHistory(limit = 100, filters = {}) {
    let trades = [...this.tradeHistory];

    // Apply filters
    if (filters.tokenMint) {
      trades = trades.filter(t => t.tokenMint === filters.tokenMint);
    }
    if (filters.action) {
      trades = trades.filter(t => t.action === filters.action);
    }
    if (filters.status) {
      trades = trades.filter(t => t.status === filters.status);
    }
    if (filters.fromDate) {
      trades = trades.filter(t => t.timestamp >= filters.fromDate);
    }
    if (filters.toDate) {
      trades = trades.filter(t => t.timestamp <= filters.toDate);
    }

    return trades.slice(-limit);
  }

  /**
   * Get performance metrics
   */
  getPerformanceMetrics() {
    return { ...this.performanceMetrics };
  }

  /**
   * Get token performance
   */
  getTokenPerformance(tokenMint = null) {
    if (tokenMint) {
      return this.tokenPerformance.get(tokenMint) || null;
    }
    return Array.from(this.tokenPerformance.values());
  }

  /**
   * Get agent statistics
   */
  getAgentStats() {
    const stats = {};
    for (const [key, value] of this.agentStats) {
      stats[key] = value;
    }
    return stats;
  }

  /**
   * Get recent activity summary
   */
  getRecentActivity(hours = 24) {
    const cutoff = Date.now() - hours * 60 * 60 * 1000;
    const recentTrades = this.tradeHistory.filter(t => t.timestamp >= cutoff);

    return {
      timeframe: `${hours}h`,
      totalTrades: recentTrades.length,
      completedTrades: recentTrades.filter(t => t.status === 'COMPLETED').length,
      failedTrades: recentTrades.filter(t => t.status === 'FAILED').length,
      totalVolume: recentTrades.reduce((sum, t) => sum + (t.amount || 0), 0),
      tokensTraded: new Set(recentTrades.map(t => t.tokenMint)).size,
    };
  }

  /**
   * Generate performance report
   */
  generateReport() {
    const metrics = this.getPerformanceMetrics();
    const recent = this.getRecentActivity(24);

    return {
      timestamp: Date.now(),
      summary: {
        totalTrades: metrics.totalTrades,
        winRate: (metrics.winRate * 100).toFixed(2) + '%',
        totalPnL: metrics.totalPnL.toFixed(4),
        profitFactor: metrics.profitFactor.toFixed(2),
        maxDrawdown: metrics.maxDrawdown.toFixed(2) + '%',
      },
      last24h: recent,
      bestTrade: metrics.bestTrade ? {
        tokenMint: metrics.bestTrade.tokenMint,
        pnl: metrics.bestTrade.pnl?.toFixed(4),
      } : null,
      worstTrade: metrics.worstTrade ? {
        tokenMint: metrics.worstTrade.tokenMint,
        pnl: metrics.worstTrade.pnl?.toFixed(4),
      } : null,
      tokenStats: this.getTokenPerformance().slice(0, 10),
    };
  }

  /**
   * Load state from file
   */
  async loadState() {
    try {
      if (fs.existsSync(this.stateFile)) {
        const data = JSON.parse(fs.readFileSync(this.stateFile, 'utf-8'));

        if (data.tradeHistory) {
          this.tradeHistory = data.tradeHistory;
        }
        if (data.performanceMetrics) {
          this.performanceMetrics = { ...this.performanceMetrics, ...data.performanceMetrics };
        }
        if (data.tokenPerformance) {
          this.tokenPerformance = new Map(data.tokenPerformance);
        }
        if (data.agentStats) {
          this.agentStats = new Map(data.agentStats);
        }

        logger.agent(this.name, 'State loaded from file');
      }
    } catch (error) {
      logger.warn('Failed to load state', { error: error.message });
    }
  }

  /**
   * Persist state to file
   */
  persistState() {
    try {
      const dir = path.dirname(this.stateFile);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      const state = {
        tradeHistory: this.tradeHistory,
        performanceMetrics: this.performanceMetrics,
        tokenPerformance: Array.from(this.tokenPerformance.entries()),
        agentStats: Array.from(this.agentStats.entries()),
        lastPersisted: Date.now(),
      };

      fs.writeFileSync(this.stateFile, JSON.stringify(state, null, 2));

      eventBus.emitEvent(EventTypes.MEMORY_STATE_PERSISTED, {
        timestamp: Date.now(),
        trades: this.tradeHistory.length,
      });

      logger.agent(this.name, 'State persisted', {
        trades: this.tradeHistory.length,
      });
    } catch (error) {
      logger.error('Failed to persist state', { error: error.message });
    }
  }

  /**
   * Start persist timer
   */
  startPersistTimer() {
    this.persistTimer = setInterval(() => {
      this.persistState();
    }, this.persistInterval);
  }

  /**
   * Stop persist timer
   */
  stopPersistTimer() {
    if (this.persistTimer) {
      clearInterval(this.persistTimer);
      this.persistTimer = null;
    }
  }

  /**
   * Trim history to max size
   */
  trimHistory() {
    if (this.tradeHistory.length > this.maxHistorySize) {
      this.tradeHistory = this.tradeHistory.slice(-this.maxHistorySize);
    }
  }

  /**
   * Generate trade ID
   */
  generateTradeId() {
    return `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get agent status
   */
  getStatus() {
    return {
      name: this.name,
      totalTrades: this.tradeHistory.length,
      performanceMetrics: this.getPerformanceMetrics(),
      tokenCount: this.tokenPerformance.size,
    };
  }

  /**
   * Clear history (use with caution)
   */
  clearHistory() {
    this.tradeHistory = [];
    this.tokenPerformance.clear();
    this.agentStats.clear();
    this.performanceMetrics = {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      totalPnL: 0,
      totalFees: 0,
      winRate: 0,
      avgWin: 0,
      avgLoss: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      maxDrawdown: 0,
      avgHoldingTime: 0,
      bestTrade: null,
      worstTrade: null,
    };
    logger.agent(this.name, 'History cleared');
  }
}

// Singleton instance
const memoryAgent = new MemoryAgent();

export { MemoryAgent, memoryAgent };
export default memoryAgent;

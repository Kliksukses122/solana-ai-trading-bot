/**
 * Analyst Agent - Technical Analysis and Signal Generation
 * Combines technical indicators with ML predictions for trading signals
 */

import { eventBus, EventTypes } from '../core/eventBus.js';
import { config } from '../config/config.js';
import indicatorService from '../services/indicatorService.js';
import mlService from '../services/mlService.js';
import dataService from '../services/dataService.js';
import logger from '../utils/logger.js';

class AnalystAgent {
  constructor() {
    this.name = 'AnalystAgent';
    this.analysisCache = new Map();
    this.cacheTimeout = 10000; // 10 seconds
    this.analysisHistory = [];
    this.maxHistory = 500;

    // Configuration
    this.minConfidence = config.scoring.minConfidenceScore;
    this.scoringWeights = config.scoring;
  }

  /**
   * Initialize the analyst agent
   */
  async initialize() {
    logger.agent(this.name, 'Initializing...');
    this.setupEventListeners();
    await mlService.initialize();
    logger.agent(this.name, 'Initialized successfully');
    return this;
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Listen for opportunities from Scout Agent
    eventBus.subscribe(EventTypes.SCOUT_OPPORTUNITY_FOUND, async (event) => {
      await this.analyzeOpportunity(event.data);
    });

    // Listen for price updates
    eventBus.subscribe(EventTypes.SCOUT_PRICE_UPDATE, async (event) => {
      await this.analyzePriceChange(event.data);
    });

    // Listen for whale activity
    eventBus.subscribe(EventTypes.SCOUT_WHALE_ACTIVITY, async (event) => {
      await this.analyzeWhaleActivity(event.data);
    });

    // Listen for trade completion for model updates
    eventBus.subscribe(EventTypes.TRADER_SWAP_SUCCESS, async (event) => {
      this.updateModelFromTrade(event.data);
    });
  }

  /**
   * Analyze an opportunity detected by Scout Agent
   */
  async analyzeOpportunity(opportunity) {
    const startTime = Date.now();

    try {
      logger.agent(this.name, 'Analyzing opportunity', { tokenMint: opportunity.tokenMint });

      // Get market data
      const marketData = await dataService.getTokenMarketData(opportunity.tokenMint);
      if (!marketData) {
        logger.warn('No market data available', { tokenMint: opportunity.tokenMint });
        return null;
      }

      // Perform technical analysis
      const priceHistory = marketData.priceHistory || [];
      const prices = priceHistory.map(p => p.price);

      if (prices.length < 30) {
        logger.debug('Insufficient price history for analysis', {
          tokenMint: opportunity.tokenMint,
          dataPoints: prices.length,
        });
        return null;
      }

      // Run comprehensive analysis
      const analysis = await indicatorService.analyze(prices);

      // Add ML prediction
      if (config.ml.enabled) {
        const mlPrediction = mlService.ensemblePredict(opportunity.tokenMint, priceHistory);
        analysis.ml = mlPrediction;
      }

      // Add market data to analysis
      analysis.marketData = marketData;
      analysis.opportunity = opportunity;

      // Generate trading signal
      const signal = this.generateSignal(analysis);

      // Cache the analysis
      this.cacheAnalysis(opportunity.tokenMint, analysis);

      // Record in history
      this.addAnalysisHistory({
        tokenMint: opportunity.tokenMint,
        signal,
        analysis,
        timestamp: Date.now(),
      });

      // Emit analysis complete event
      eventBus.emitEvent(EventTypes.ANALYST_ANALYSIS_COMPLETE, {
        tokenMint: opportunity.tokenMint,
        signal,
        analysis,
      });

      const duration = Date.now() - startTime;
      logger.performance('analyst_analysis', duration, { tokenMint: opportunity.tokenMint });

      return { signal, analysis };
    } catch (error) {
      logger.error('Failed to analyze opportunity', {
        tokenMint: opportunity.tokenMint,
        error: error.message,
      });
      return null;
    }
  }

  /**
   * Analyze price change event
   */
  async analyzePriceChange(priceData) {
    try {
      const { tokenMint, price, priceChange } = priceData;

      // Check cache first
      const cached = this.getAnalysisFromCache(tokenMint);
      if (cached) {
        // Update cached analysis with new price
        cached.analysis.price = price;
        cached.analysis.priceChange = priceChange;

        // Quick signal update
        if (Math.abs(priceChange) >= 5) { // 5% change threshold
          const signal = this.generateSignal(cached.analysis);
          eventBus.emitEvent(EventTypes.ANALYST_SIGNAL_GENERATED, {
            tokenMint,
            signal,
            reason: 'PRICE_CHANGE',
          });
        }
      }
    } catch (error) {
      logger.error('Failed to analyze price change', { error: error.message });
    }
  }

  /**
   * Analyze whale activity
   */
  async analyzeWhaleActivity(activityData) {
    try {
      const { tokenMint, amount, direction } = activityData;

      // Whales buying is bullish, selling is bearish
      const whaleSignal = {
        direction: direction === 'BUY' ? 'BUY' : 'SELL',
        confidence: Math.min(1, amount / 1000), // Higher amount = higher confidence
        source: 'WHALE_ACTIVITY',
        data: activityData,
      };

      eventBus.emitEvent(EventTypes.ANALYST_SIGNAL_GENERATED, {
        tokenMint,
        signal: whaleSignal,
        reason: 'WHALE_ACTIVITY',
      });
    } catch (error) {
      logger.error('Failed to analyze whale activity', { error: error.message });
    }
  }

  /**
   * Generate trading signal from analysis
   */
  generateSignal(analysis) {
    const signal = {
      action: 'HOLD',
      confidence: 0,
      score: 0,
      reasons: [],
      components: {},
    };

    // Calculate weighted score
    let totalScore = 0;
    let totalWeight = 0;

    // Technical indicator scores
    const indicatorScores = this.calculateIndicatorScores(analysis);

    for (const [indicator, data] of Object.entries(indicatorScores)) {
      const weight = this.scoringWeights[`${indicator}Weight`] || 0.1;
      totalScore += data.score * weight;
      totalWeight += weight;
      signal.components[indicator] = data;

      if (data.signal !== 'NEUTRAL') {
        signal.reasons.push(`${indicator}: ${data.signal} (${data.score.toFixed(2)})`);
      }
    }

    // ML prediction contribution
    if (analysis.ml) {
      const mlScore = this.getMlScore(analysis.ml);
      const mlWeight = this.scoringWeights.mlPredictionWeight || 0.3;
      totalScore += mlScore.score * mlWeight;
      totalWeight += mlWeight;
      signal.components.ml = mlScore;

      if (mlScore.signal !== 'NEUTRAL') {
        signal.reasons.push(`ML: ${mlScore.signal} (${mlScore.confidence.toFixed(2)})`);
      }
    }

    // Market data contribution
    if (analysis.marketData) {
      const marketScore = this.getMarketScore(analysis.marketData);
      totalScore += marketScore.score * 0.1;
      totalWeight += 0.1;
      signal.components.market = marketScore;
    }

    // Normalize score
    signal.score = totalWeight > 0 ? totalScore / totalWeight : 0;
    signal.confidence = Math.min(1, Math.abs(signal.score));

    // Determine action
    if (signal.score >= this.minConfidence) {
      signal.action = 'BUY';
    } else if (signal.score <= -this.minConfidence) {
      signal.action = 'SELL';
    }

    // Add opportunity context
    if (analysis.opportunity) {
      signal.opportunityType = analysis.opportunity.type;
      signal.opportunityScore = analysis.opportunity.score;
    }

    return signal;
  }

  /**
   * Calculate scores for each indicator
   */
  calculateIndicatorScores(analysis) {
    const scores = {};

    // RSI
    if (analysis.indicators?.rsi !== null && analysis.indicators?.rsi !== undefined) {
      const rsi = analysis.indicators.rsi;
      let rsiScore = 0;
      if (rsi < 30) rsiScore = (30 - rsi) / 30; // Oversold = bullish
      else if (rsi > 70) rsiScore = -(rsi - 70) / 30; // Overbought = bearish
      scores.rsi = {
        value: rsi,
        score: rsiScore,
        signal: analysis.signals.rsi,
      };
    }

    // MACD
    if (analysis.indicators?.macd) {
      const macd = analysis.indicators.macd;
      scores.macd = {
        value: macd.histogram,
        score: Math.max(-1, Math.min(1, macd.histogram * 100)),
        signal: analysis.signals.macd,
        trend: macd.trend,
      };
    }

    // EMA
    if (analysis.indicators?.ema) {
      const ema = analysis.indicators.ema;
      const emaScore = ema.trend === 'BULLISH' ? 0.5 : -0.5;
      scores.ema = {
        short: ema.shortEMA,
        long: ema.longEMA,
        score: emaScore,
        signal: ema.signal,
        trend: ema.trend,
      };
    }

    // Momentum
    if (analysis.indicators?.momentum) {
      const momentum = analysis.indicators.momentum;
      scores.momentum = {
        value: momentum.momentum,
        score: Math.max(-1, Math.min(1, momentum.momentum / 10)),
        signal: momentum.signal,
        trend: momentum.momentumTrend,
      };
    }

    // Bollinger Bands
    if (analysis.indicators?.bollingerBands) {
      const bb = analysis.indicators.bollingerBands;
      let bbScore = 0;
      if (bb.percentB < 0) bbScore = 1 - bb.percentB; // Below lower band = bullish
      else if (bb.percentB > 1) bbScore = -(bb.percentB - 1); // Above upper = bearish
      scores.bollingerBands = {
        percentB: bb.percentB,
        score: bbScore,
        signal: bb.signal,
        bandwidth: bb.bandwidth,
      };
    }

    // Volume
    if (analysis.indicators?.volume) {
      const volume = analysis.indicators.volume;
      scores.volume = {
        ratio: volume.volumeRatio,
        score: volume.volumeSpike ? 0.3 : 0,
        signal: volume.signal,
        trend: volume.volumeTrend,
      };
    }

    return scores;
  }

  /**
   * Get ML prediction score
   */
  getMlScore(mlPrediction) {
    const { prediction, confidence } = mlPrediction;
    let score = 0;

    if (prediction === 'UP') {
      score = confidence;
    } else if (prediction === 'DOWN') {
      score = -confidence;
    }

    return {
      prediction,
      confidence,
      score,
      signal: prediction,
    };
  }

  /**
   * Get market data score
   */
  getMarketScore(marketData) {
    let score = 0;

    // Price change momentum
    if (marketData.priceChange24h) {
      score += Math.max(-0.3, Math.min(0.3, marketData.priceChange24h / 100));
    }

    // Liquidity bonus
    if (marketData.liquidity > 100000) {
      score += 0.1;
    }

    // Volume spike bonus
    if (marketData.volume24h > marketData.liquidity) {
      score += 0.1;
    }

    return {
      score,
      liquidity: marketData.liquidity,
      volume24h: marketData.volume24h,
    };
  }

  /**
   * Update ML model based on trade outcome
   */
  updateModelFromTrade(tradeData) {
    if (!config.ml.enabled) return;

    try {
      const { tokenMint, action, profit } = tradeData;
      const actualDirection = profit > 0 ? action : action === 'BUY' ? 'SELL' : 'BUY';
      mlService.updateModel(tokenMint, actualDirection);
    } catch (error) {
      logger.error('Failed to update ML model', { error: error.message });
    }
  }

  /**
   * Cache analysis result
   */
  cacheAnalysis(tokenMint, analysis) {
    this.analysisCache.set(tokenMint, {
      analysis,
      timestamp: Date.now(),
    });
  }

  /**
   * Get analysis from cache
   */
  getAnalysisFromCache(tokenMint) {
    const cached = this.analysisCache.get(tokenMint);
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      return cached;
    }
    return null;
  }

  /**
   * Add to analysis history
   */
  addAnalysisHistory(record) {
    this.analysisHistory.push(record);
    if (this.analysisHistory.length > this.maxHistory) {
      this.analysisHistory.shift();
    }
  }

  /**
   * Get agent status
   */
  getStatus() {
    return {
      name: this.name,
      cacheSize: this.analysisCache.size,
      historySize: this.analysisHistory.length,
      minConfidence: this.minConfidence,
      mlEnabled: config.ml.enabled,
      mlStats: mlService.getAllModelStats(),
    };
  }

  /**
   * Get analysis history
   */
  getHistory(limit = 50) {
    return this.analysisHistory.slice(-limit);
  }

  /**
   * Manual analysis trigger
   */
  async manualAnalyze(tokenMint) {
    const opportunity = {
      tokenMint,
      symbol: tokenMint.slice(0, 8),
      score: 1,
      timestamp: Date.now(),
      type: 'MANUAL',
    };

    return this.analyzeOpportunity(opportunity);
  }
}

// Singleton instance
const analystAgent = new AnalystAgent();

export { AnalystAgent, analystAgent };
export default analystAgent;

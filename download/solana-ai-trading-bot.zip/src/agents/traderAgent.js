/**
 * Trader Agent - Trade Execution
 * Handles Jupiter swaps, transaction signing, and execution
 */

import { eventBus, EventTypes } from '../core/eventBus.js';
import { config } from '../config/config.js';
import walletService from '../services/walletService.js';
import jupiterService from '../services/jupiterService.js';
import dataService from '../services/dataService.js';
import logger from '../utils/logger.js';

class TraderAgent {
  constructor() {
    this.name = 'TraderAgent';
    this.pendingTransactions = new Map();
    this.completedTrades = [];
    this.maxHistorySize = 500;
    this.mockMode = config.bot.mockMode;

    // Configuration
    this.defaultSlippage = config.trading.slippageBps;
    this.maxRetries = 3;
    this.retryDelay = 2000;
  }

  /**
   * Initialize the trader agent
   */
  async initialize() {
    logger.agent(this.name, 'Initializing...');
    this.setupEventListeners();
    await walletService.initialize();
    logger.agent(this.name, 'Initialized successfully', {
      mockMode: this.mockMode,
      walletAddress: walletService.publicKey?.toBase58(),
    });
    return this;
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    // Listen for approved trades from Risk Agent
    eventBus.subscribe(EventTypes.RISK_APPROVED, async (event) => {
      await this.executeTrade(event.data);
    });

    // Listen for position close requests
    eventBus.subscribe('trader:close_position', async (event) => {
      await this.closePosition(event.data);
    });
  }

  /**
   * Execute a trade
   */
  async executeTrade(tradeRequest) {
    const startTime = Date.now();
    const {
      tokenMint,
      action,
      approvedAmount,
      stopLoss,
      takeProfit,
      signal,
    } = tradeRequest;

    const tradeId = this.generateTradeId();

    try {
      logger.agent(this.name, 'Executing trade', {
        tradeId,
        tokenMint,
        action,
        amount: approvedAmount,
      });

      // Record pending transaction
      this.pendingTransactions.set(tradeId, {
        tokenMint,
        action,
        amount: approvedAmount,
        startTime,
        status: 'PENDING',
      });

      // Emit swap initiated event
      eventBus.emitEvent(EventTypes.TRADER_SWAP_INITIATED, {
        tradeId,
        tokenMint,
        action,
        amount: approvedAmount,
      });

      // Get current price
      const price = await dataService.getTokenPrice(tokenMint);

      // Determine input/output mints based on action
      const solMint = 'So11111111111111111111111111111111111111112';
      const inputMint = action === 'BUY' ? solMint : tokenMint;
      const outputMint = action === 'BUY' ? tokenMint : solMint;

      // Convert amount to lamports/smallest unit
      const amountIn = action === 'BUY'
        ? Math.floor(approvedAmount * 1e9) // SOL to lamports
        : Math.floor(approvedAmount); // Assume token already in smallest unit

      let result;

      if (this.mockMode) {
        // Mock trade execution
        result = await this.executeMockTrade({
          tradeId,
          inputMint,
          outputMint,
          amountIn,
          action,
          price,
        });
      } else {
        // Real trade execution via Jupiter
        result = await this.executeRealTrade({
          tradeId,
          inputMint,
          outputMint,
          amountIn,
          action,
        });
      }

      const duration = Date.now() - startTime;

      if (result.success) {
        // Record completed trade
        const completedTrade = {
          tradeId,
          tokenMint,
          action,
          amount: approvedAmount,
          inAmount: result.inAmount,
          outAmount: result.outAmount,
          price: price || result.price,
          signature: result.signature,
          stopLoss,
          takeProfit,
          signal,
          duration,
          timestamp: Date.now(),
          status: 'COMPLETED',
          mock: this.mockMode,
        };

        this.completedTrades.push(completedTrade);
        this.trimHistory();

        // Update pending status
        const pending = this.pendingTransactions.get(tradeId);
        if (pending) {
          pending.status = 'COMPLETED';
          pending.signature = result.signature;
        }

        // Emit success event
        eventBus.emitEvent(EventTypes.TRADER_SWAP_SUCCESS, completedTrade);

        logger.success('Trade completed', {
          tradeId,
          action,
          amount: approvedAmount,
          signature: result.signature,
          duration,
        });

        return completedTrade;
      } else {
        throw new Error(result.error || 'Trade execution failed');
      }
    } catch (error) {
      const duration = Date.now() - startTime;

      // Update pending status
      const pending = this.pendingTransactions.get(tradeId);
      if (pending) {
        pending.status = 'FAILED';
        pending.error = error.message;
      }

      // Emit failure event
      const failureData = {
        tradeId,
        tokenMint,
        action,
        amount: approvedAmount,
        error: error.message,
        duration,
        timestamp: Date.now(),
      };

      eventBus.emitEvent(EventTypes.TRADER_SWAP_FAILED, failureData);

      logger.error('Trade failed', {
        tradeId,
        error: error.message,
        duration,
      });

      return {
        success: false,
        ...failureData,
      };
    }
  }

  /**
   * Execute mock trade (paper trading)
   */
  async executeMockTrade(params) {
    const { tradeId, inputMint, outputMint, amountIn, action, price } = params;

    // Simulate network delay
    await this.delay(500 + Math.random() * 1000);

    // Generate mock amounts
    const mockPrice = price || 1;
    const slippageFactor = 1 - (this.defaultSlippage / 10000) * Math.random();
    const outAmount = action === 'BUY'
      ? Math.floor((amountIn / 1e9) / mockPrice * slippageFactor * 1e6) // Mock token units
      : Math.floor(amountIn * mockPrice * slippageFactor); // Mock lamports

    const mockSignature = `mock_${tradeId}_${Date.now()}`;

    logger.info('Mock trade executed', {
      tradeId,
      action,
      inAmount: amountIn,
      outAmount,
      mockSignature,
    });

    return {
      success: true,
      signature: mockSignature,
      inAmount: amountIn,
      outAmount,
      price: mockPrice,
    };
  }

  /**
   * Execute real trade via Jupiter
   */
  async executeRealTrade(params) {
    const { tradeId, inputMint, outputMint, amountIn, action } = params;

    // Retry logic
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        logger.debug('Attempt trade execution', { tradeId, attempt });

        // Execute swap via Jupiter service
        const result = await jupiterService.executeSwap(
          walletService,
          inputMint,
          outputMint,
          amountIn,
          { slippageBps: this.defaultSlippage }
        );

        if (result.success) {
          return result;
        }

        // If not last attempt, wait before retry
        if (attempt < this.maxRetries) {
          await this.delay(this.retryDelay * attempt);
        }
      } catch (error) {
        logger.warn('Trade attempt failed', {
          tradeId,
          attempt,
          error: error.message,
        });

        if (attempt === this.maxRetries) {
          return {
            success: false,
            error: error.message,
          };
        }

        await this.delay(this.retryDelay * attempt);
      }
    }

    return {
      success: false,
      error: 'Max retries exceeded',
    };
  }

  /**
   * Close an existing position
   */
  async closePosition(positionData) {
    const { tokenMint, amount, exitReason } = positionData;

    logger.agent(this.name, 'Closing position', {
      tokenMint,
      amount,
      exitReason,
    });

    // Execute sell trade
    const closeRequest = {
      tokenMint,
      action: 'SELL',
      approvedAmount: amount,
      exitReason,
    };

    return this.executeTrade(closeRequest);
  }

  /**
   * Get quote for potential trade
   */
  async getQuote(tokenMint, action, amount) {
    const solMint = 'So11111111111111111111111111111111111111112';
    const inputMint = action === 'BUY' ? solMint : tokenMint;
    const outputMint = action === 'BUY' ? tokenMint : solMint;

    const amountIn = action === 'BUY'
      ? Math.floor(amount * 1e9)
      : Math.floor(amount);

    const quote = await jupiterService.getQuote(inputMint, outputMint, amountIn);

    if (quote.success) {
      eventBus.emitEvent(EventTypes.TRADER_QUOTE_RECEIVED, {
        tokenMint,
        action,
        amount,
        quote,
      });
    }

    return quote;
  }

  /**
   * Check wallet balance
   */
  async checkBalance() {
    const balance = await walletService.getBalanceSol();
    return {
      solBalance: balance,
      address: walletService.publicKey?.toBase58(),
    };
  }

  /**
   * Get pending transactions
   */
  getPendingTransactions() {
    return Array.from(this.pendingTransactions.values());
  }

  /**
   * Get completed trades
   */
  getCompletedTrades(limit = 100) {
    return this.completedTrades.slice(-limit);
  }

  /**
   * Trim history
   */
  trimHistory() {
    if (this.completedTrades.length > this.maxHistorySize) {
      this.completedTrades = this.completedTrades.slice(-this.maxHistorySize);
    }
  }

  /**
   * Generate unique trade ID
   */
  generateTradeId() {
    return `trade_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Helper delay
   */
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Get agent status
   */
  getStatus() {
    return {
      name: this.name,
      mockMode: this.mockMode,
      walletAddress: walletService.publicKey?.toBase58(),
      pendingTransactions: this.pendingTransactions.size,
      completedTrades: this.completedTrades.length,
      defaultSlippage: this.defaultSlippage,
    };
  }

  /**
   * Calculate potential profit/loss
   */
  calculatePnL(trade, currentPrice) {
    if (!trade || !currentPrice) return null;

    const entryPrice = trade.price;
    const amount = trade.amount;

    let pnl, pnlPercent;

    if (trade.action === 'BUY') {
      pnl = (currentPrice - entryPrice) * amount;
      pnlPercent = ((currentPrice - entryPrice) / entryPrice) * 100;
    } else {
      pnl = (entryPrice - currentPrice) * amount;
      pnlPercent = ((entryPrice - currentPrice) / entryPrice) * 100;
    }

    return {
      pnl,
      pnlPercent,
      entryPrice,
      currentPrice,
      amount,
    };
  }
}

// Singleton instance
const traderAgent = new TraderAgent();

export { TraderAgent, traderAgent };
export default traderAgent;

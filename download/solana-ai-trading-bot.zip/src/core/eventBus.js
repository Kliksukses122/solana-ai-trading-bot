/**
 * Event Bus - Central event-driven communication system
 * Enables loose coupling between agents
 */

import EventEmitter from 'events';

class EventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(50);
    this.eventHistory = [];
    this.maxHistorySize = 1000;
  }

  // Emit event with history tracking
  emitEvent(eventName, data) {
    const event = {
      name: eventName,
      data,
      timestamp: Date.now(),
      id: this.generateEventId(),
    };

    // Store in history
    this.eventHistory.push(event);
    if (this.eventHistory.length > this.maxHistorySize) {
      this.eventHistory.shift();
    }

    // Emit the event
    this.emit(eventName, event);
    this.emit('*', event); // Wildcard listener

    return event;
  }

  // Subscribe to event
  subscribe(eventName, listener) {
    this.on(eventName, listener);
    return () => this.off(eventName, listener);
  }

  // Subscribe once
  subscribeOnce(eventName, listener) {
    this.once(eventName, listener);
  }

  // Get event history
  getHistory(eventName = null, limit = 100) {
    let history = this.eventHistory;
    if (eventName) {
      history = history.filter(e => e.name === eventName);
    }
    return history.slice(-limit);
  }

  // Clear history
  clearHistory() {
    this.eventHistory = [];
  }

  // Generate unique event ID
  generateEventId() {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Async emit with error handling
  async emitAsync(eventName, data) {
    const event = this.emitEvent(eventName, data);
    return event;
  }

  // Wait for event
  waitFor(eventName, timeout = 30000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error(`Timeout waiting for event: ${eventName}`));
      }, timeout);

      this.once(eventName, (event) => {
        clearTimeout(timer);
        resolve(event);
      });
    });
  }
}

// Event Types Constants
const EventTypes = {
  // Scout Events
  SCOUT_TOKEN_DETECTED: 'scout:token_detected',
  SCOUT_OPPORTUNITY_FOUND: 'scout:opportunity_found',
  SCOUT_WHALE_ACTIVITY: 'scout:whale_activity',
  SCOUT_VOLUME_SPIKE: 'scout:volume_spike',
  SCOUT_NEW_TOKEN: 'scout:new_token',
  SCOUT_PRICE_UPDATE: 'scout:price_update',

  // Analyst Events
  ANALYST_ANALYSIS_COMPLETE: 'analyst:analysis_complete',
  ANALYST_SIGNAL_GENERATED: 'analyst:signal_generated',
  ANALYST_CONFIDENCE_LOW: 'analyst:confidence_low',

  // Risk Events
  RISK_APPROVED: 'risk:approved',
  RISK_REJECTED: 'risk:rejected',
  RISK_WARNING: 'risk:warning',
  RISK_EMERGENCY_STOP: 'risk:emergency_stop',

  // Trader Events
  TRADER_QUOTE_RECEIVED: 'trader:quote_received',
  TRADER_SWAP_INITIATED: 'trader:swap_initiated',
  TRADER_SWAP_SUCCESS: 'trader:swap_success',
  TRADER_SWAP_FAILED: 'trader:swap_failed',
  TRADER_TRANSACTION_PENDING: 'trader:transaction_pending',

  // Manager Events
  MANAGER_TRADE_APPROVED: 'manager:trade_approved',
  MANAGER_TRADE_REJECTED: 'manager:trade_rejected',
  MANAGER_COOLDOWN_ACTIVE: 'manager:cooldown_active',
  MANAGER_DUPLICATE_TRADE: 'manager:duplicate_trade',
  MANAGER_LOOP_START: 'manager:loop_start',
  MANAGER_LOOP_END: 'manager:loop_end',

  // Memory Events
  MEMORY_TRADE_RECORDED: 'memory:trade_recorded',
  MEMORY_STATS_UPDATED: 'memory:stats_updated',
  MEMORY_STATE_PERSISTED: 'memory:state_persisted',

  // System Events
  SYSTEM_START: 'system:start',
  SYSTEM_STOP: 'system:stop',
  SYSTEM_ERROR: 'system:error',
  SYSTEM_WARNING: 'system:warning',
};

// Singleton instance
const eventBus = new EventBus();

export { EventBus, EventTypes, eventBus };
export default eventBus;

/**
 * Logger Utility - Comprehensive logging system
 * Supports multiple log levels, file output, and structured logging
 */

import fs from 'fs';
import path from 'path';

class Logger {
  constructor(options = {}) {
    this.level = options.level || 'info';
    this.logFile = options.file || './logs/trading.log';
    this.consoleOutput = options.console !== false;
    this.colors = {
      debug: '\x1b[36m',  // Cyan
      info: '\x1b[32m',   // Green
      warn: '\x1b[33m',   // Yellow
      error: '\x1b[31m',  // Red
      success: '\x1b[35m', // Magenta
      reset: '\x1b[0m',
    };
    this.levels = {
      debug: 0,
      info: 1,
      warn: 2,
      error: 3,
      success: 1,
    };

    this.ensureLogDirectory();
  }

  ensureLogDirectory() {
    const dir = path.dirname(this.logFile);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  formatMessage(level, message, meta = {}) {
    const timestamp = new Date().toISOString();
    const formattedMeta = Object.keys(meta).length > 0
      ? ` | ${JSON.stringify(meta)}`
      : '';
    return `[${timestamp}] [${level.toUpperCase()}] ${message}${formattedMeta}`;
  }

  log(level, message, meta = {}) {
    if (this.levels[level] < this.levels[this.level]) {
      return;
    }

    const formattedMessage = this.formatMessage(level, message, meta);
    const color = this.colors[level] || this.colors.reset;

    // Console output
    if (this.consoleOutput) {
      console.log(`${color}${formattedMessage}${this.colors.reset}`);
    }

    // File output
    this.writeToFile(formattedMessage);
  }

  writeToFile(message) {
    try {
      fs.appendFileSync(this.logFile, message + '\n');
    } catch (error) {
      console.error('Failed to write to log file:', error.message);
    }
  }

  debug(message, meta = {}) {
    this.log('debug', message, meta);
  }

  info(message, meta = {}) {
    this.log('info', message, meta);
  }

  warn(message, meta = {}) {
    this.log('warn', message, meta);
  }

  error(message, meta = {}) {
    this.log('error', message, meta);
  }

  success(message, meta = {}) {
    this.log('success', message, meta);
  }

  // Trade-specific logging
  trade(trade) {
    const message = `TRADE: ${trade.action} ${trade.amount} ${trade.token} @ ${trade.price}`;
    this.info(message, {
      type: 'trade',
      action: trade.action,
      token: trade.token,
      amount: trade.amount,
      price: trade.price,
      txId: trade.txId,
      pnl: trade.pnl,
    });
  }

  // Performance logging
  performance(operation, duration, meta = {}) {
    this.debug(`PERF: ${operation} took ${duration}ms`, {
      ...meta,
      operation,
      duration,
    });
  }

  // Agent activity logging
  agent(agentName, action, data = {}) {
    this.info(`AGENT [${agentName}]: ${action}`, {
      agent: agentName,
      action,
      ...data,
    });
  }

  // Error with stack trace
  errorWithStack(message, error) {
    this.error(message, {
      error: error.message,
      stack: error.stack,
    });
  }

  // Create child logger with context
  child(context = {}) {
    const childLogger = new Logger({
      level: this.level,
      file: this.logFile,
      console: this.consoleOutput,
    });

    // Override log method to include context
    const originalLog = childLogger.log.bind(childLogger);
    childLogger.log = (level, message, meta = {}) => {
      originalLog(level, message, { ...context, ...meta });
    };

    return childLogger;
  }

  // Rotate log file
  rotate() {
    if (fs.existsSync(this.logFile)) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const rotatedFile = `${this.logFile}.${timestamp}`;
      fs.renameSync(this.logFile, rotatedFile);
      this.info('Log file rotated', { oldFile: rotatedFile });
    }
  }
}

// Create singleton instance
import { config } from '../config/config.js';
const logger = new Logger(config.logging);

export { Logger, logger };
export default logger;

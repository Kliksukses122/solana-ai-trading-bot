/**
 * Configuration Module for Solana AI Trading Bot
 * Centralized configuration management with environment variables
 */

import dotenv from 'dotenv';
dotenv.config();

const config = {
  // Solana Network Configuration
  solana: {
    rpcUrl: process.env.RPC_URL || 'https://api.mainnet-beta.solana.com',
    wsUrl: process.env.WS_URL || 'wss://api.mainnet-beta.solana.com',
    commitment: 'confirmed',
    maxRetries: 3,
    retryDelay: 1000,
  },

  // Wallet Configuration
  wallet: {
    privateKey: process.env.PRIVATE_KEY || '',
    address: process.env.WALLET_ADDRESS || '',
    inputMint: process.env.INPUT_MINT || 'So11111111111111111111111111111111111111112', // SOL
    outputMint: process.env.OUTPUT_MINT || 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC
  },

  // Trading Parameters - HIGH RISK HIGH RETURN
  trading: {
    tradeSizeSol: parseFloat(process.env.TRADE_SIZE_SOL) || 0.01,
    maxRiskPercent: parseFloat(process.env.MAX_RISK_PERCENT) || 5,
    stopLossPercent: parseFloat(process.env.STOP_LOSS_PERCENT) || 15,
    takeProfitPercent: parseFloat(process.env.TAKE_PROFIT_PERCENT) || 30,
    slippageBps: parseInt(process.env.SLIPPAGE_BPS) || 100,
    cooldownSeconds: parseInt(process.env.COOLDOWN_SECONDS) || 30,
    scanIntervalMs: parseInt(process.env.SCAN_INTERVAL_MS) || 3000,
    maxOpenTrades: 5,
    minLiquidityUsd: 5000,
    minVolume24h: 2000,
  },

  // Risk Management - Aggressive for Meme Tokens
  risk: {
    maxPositionSizePercent: 10,
    maxDailyLossPercent: 20,
    maxDrawdownPercent: 30,
    emergencyStopEnabled: true,
    blacklistTokens: [],
    whitelistTokens: [],
  },

  // Technical Indicators
  indicators: {
    rsi: {
      period: 14,
      overbought: 70,
      oversold: 30,
    },
    macd: {
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
    },
    bollingerBands: {
      period: 20,
      stdDev: 2,
    },
    ema: {
      shortPeriod: 9,
      longPeriod: 21,
    },
  },

  // Scoring Weights for Analyst Agent - Aggressive Meme Trading
  scoring: {
    rsiWeight: 0.15,
    macdWeight: 0.15,
    volumeWeight: 0.25,      // Higher weight on volume (important for memes)
    momentumWeight: 0.20,    // Higher weight on momentum
    mlPredictionWeight: 0.25,
    minConfidenceScore: 0.55, // Lower threshold for more trades
  },

  // API Keys
  apiKeys: {
    helius: process.env.HELIUS_API_KEY || '',
    birdeye: process.env.BIRDEYE_API_KEY || '',
  },

  // Whale Tracking
  whaleTracking: {
    enabled: true,
    minWhaleAmount: parseFloat(process.env.WHALE_MIN_AMOUNT) || 100,
    trackedWallets: (process.env.WHALE_WALLET_ADDRESSES || '').split(',').filter(Boolean),
  },

  // ML Configuration
  ml: {
    enabled: process.env.ML_ENABLED === 'true',
    modelPath: process.env.ML_MODEL_PATH || './models',
    predictionThreshold: 0.6,
    retrainInterval: 86400000, // 24 hours
  },

  // Bot Mode
  bot: {
    mockMode: process.env.MOCK_MODE === 'true',
    dashboardPort: parseInt(process.env.DASHBOARD_PORT) || 3000,
  },

  // Logging Configuration
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: process.env.LOG_FILE || './logs/trading.log',
    maxSize: 10485760, // 10MB
    maxFiles: 5,
  },

  // Jupiter API Configuration
  jupiter: {
    quoteApiUrl: 'https://quote-api.jup.ag/v6',
    timeout: 30000,
    maxRetries: 3,
  },

  // Token Lists for Multi-Token Scanning - MEME TOKENS FOCUSED
  tokenLists: {
    // Hot Meme Tokens - HIGH RISK HIGH RETURN
    memeTokens: [
      'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm', // WIF (dogwifhat) - #1 Solana Meme
      'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263', // BONK - OG Solana Meme
      '7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr', // POPCAT - Viral Cat Meme
      'HeLp6nuQtko8ByJvi8u9N4yVAeWNgE7ofcQiMbM4Djm', // Slerf
      'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN', // JUP - Not meme but popular
    ],
    // New/Trending Meme Tokens
    trendingMemes: [
      'MEW1g4W9WiqLHFqdMtbFwY7Xt4HMT7Xj8CKxT3V3yCf', // MEW (cat in dogs world)
      '3Sj5AKQ2kFDJdcg2zxdPgGiTwHM6dW6cMG8dXVQYq6aG', // MANEKI
      'AZsHE6T5WdZv5Yh4Y6UQ9Ji1VZqXhQK3WBkYzTXVgJmL', // PONKE
    ],
    popular: [
      'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm', // WIF
      'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263', // BONK
      '7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr', // POPCAT
      'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC
      'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', // USDT
      'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN', // JUP
    ],
    stablecoins: [
      'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC
      'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', // USDT
    ],
  },

  // Memory and State
  memory: {
    maxTradeHistory: 1000,
    maxPriceHistory: 10000,
    statePersistInterval: 60000, // 1 minute
  },
};

// Validation
function validateConfig() {
  const errors = [];

  if (!config.wallet.privateKey && !config.bot.mockMode) {
    errors.push('PRIVATE_KEY is required in non-mock mode');
  }

  if (config.trading.tradeSizeSol <= 0) {
    errors.push('TRADE_SIZE_SOL must be positive');
  }

  if (config.trading.maxRiskPercent <= 0 || config.trading.maxRiskPercent > 100) {
    errors.push('MAX_RISK_PERCENT must be between 0 and 100');
  }

  if (errors.length > 0) {
    console.error('Configuration errors:', errors);
    if (!config.bot.mockMode) {
      process.exit(1);
    }
  }

  return errors.length === 0;
}

export { config, validateConfig };
export default config;
